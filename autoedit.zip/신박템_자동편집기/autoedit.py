# -*- coding: utf-8 -*-
"""
신박템 자동편집기
원본 제품 영상 -> (Gemini 무료 API로 분석) -> 6~8초 편집 + 자막 + 썸네일 + 캡션
업로드는 사람이 직접 한다.
"""
import os, sys, json, time, re, shutil, subprocess, urllib.request, urllib.error, math, random, glob

HERE = os.path.dirname(os.path.abspath(__file__))
FONT_DIR = os.path.join(HERE, "fonts")
VIDEO_EXT = (".mp4", ".mov", ".m4v", ".webm", ".mkv")
API = "https://generativelanguage.googleapis.com"

DEFAULT_SETTINGS = {
    "api_key": "",
    "model": "auto",
    "persona_name": "김소다",
    "persona_desc": "20대 중반 직장인, 자취. 호기심 많고 사고 나서 합리화함. 반말, 짧게, ㅋㅋㅋ·ㅠㅠ 자주 씀. 광고 말투(강력 추천, 필수템, 효과 보장) 금지.",
    "cta": "이거 궁금하면 댓글에 '좋아' 남겨줘! 링크 보내줄게 💌",
    "coupang_notice": "이 게시물은 쿠팡 파트너스 활동의 일환으로, 이에 따른 일정액의 수수료를 제공받습니다.",
    "ad_label": True,
    "keep_audio": False,
    "min_seconds": 5,
    "max_seconds": 10,
    "sub_font": "Jua-Regular.ttf",
    "thumb_font": "Jua-Regular.ttf",
    "thumb_character": "",
    "thumb_char_pos": "문구 옆",
}

CHAR_POSITIONS = ["문구 옆", "오른쪽 아래", "왼쪽 아래"]

def log(msg):
    print(msg, flush=True)

# ---------------------------------------------------------------- settings
def load_settings(path=None):
    path = path or os.path.join(HERE, "settings.json")
    s = dict(DEFAULT_SETTINGS)
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            s.update(json.load(f))
    if os.environ.get("GEMINI_API_KEY") and not s.get("api_key"):
        s["api_key"] = os.environ["GEMINI_API_KEY"]
    return s

def save_settings(s, path=None):
    path = path or os.path.join(HERE, "settings.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(s, f, ensure_ascii=False, indent=2)

# ---------------------------------------------------------------- ffmpeg
def find_ffmpeg():
    cand = [os.path.join(HERE, "ffmpeg.exe"), shutil.which("ffmpeg")]
    try:
        import imageio_ffmpeg
        cand.append(imageio_ffmpeg.get_ffmpeg_exe())
    except Exception:
        pass
    cand.append(r"C:\Program Files (x86)\Buzz\_internal\ffmpeg.exe")
    for c in cand:
        if c and os.path.exists(c):
            return c
    raise RuntimeError("ffmpeg를 찾을 수 없어요. install.bat을 먼저 실행해 주세요.")

FFMPEG = None
def ff(args, quiet=True):
    global FFMPEG
    FFMPEG = FFMPEG or find_ffmpeg()
    cmd = [FFMPEG, "-hide_banner", "-y"] + args
    p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if p.returncode != 0:
        raise RuntimeError("ffmpeg 오류:\n" + p.stderr[-2000:])
    return p

def probe(path):
    global FFMPEG
    FFMPEG = FFMPEG or find_ffmpeg()
    p = subprocess.run([FFMPEG, "-hide_banner", "-i", path], capture_output=True, text=True, encoding="utf-8", errors="replace")
    err = p.stderr
    m = re.search(r"Duration: (\d+):(\d+):([\d.]+)", err)
    dur = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3)) if m else 0.0
    has_audio = bool(re.search(r"Stream #.*Audio:", err))
    m2 = re.search(r"Stream #.*Video:.*?(\d{2,5})x(\d{2,5})", err)
    w, h = (int(m2.group(1)), int(m2.group(2))) if m2 else (0, 0)
    return {"duration": dur, "has_audio": has_audio, "w": w, "h": h}

# ---------------------------------------------------------------- Gemini (REST, 무료 키)
def _req(method, url, data=None, headers=None, raw=False, timeout=300):
    req = urllib.request.Request(url, data=data, method=method, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            body = r.read()
            return (r, body) if raw else json.loads(body.decode("utf-8"))
    except urllib.error.HTTPError as e:
        msg = e.read().decode("utf-8", "replace")
        raise RuntimeError(f"Gemini API 오류 {e.code}: {msg[:800]}")

def pick_model(key):
    data = _req("GET", f"{API}/v1beta/models?key={key}&pageSize=200")
    names = []
    for m in data.get("models", []):
        n = m["name"].split("/")[-1]
        if "generateContent" not in m.get("supportedGenerationMethods", []):
            continue
        if "flash" not in n or any(b in n for b in ("image", "tts", "live", "audio", "embedding", "thinking", "exp", "robotics", "omni")):
            continue
        names.append(n)
    if not names:
        raise RuntimeError("쓸 수 있는 Gemini Flash 모델을 찾지 못했어요. settings.json의 model을 직접 적어주세요.")
    def score(n):
        v = re.findall(r"(\d+(?:\.\d+)?)", n)
        ver = float(v[0]) if v else 0
        return (("latest" in n), "lite" not in n, "preview" not in n, ver)
    names.sort(key=score, reverse=True)
    return names[0]

def upload_file(key, path, mime="video/mp4"):
    size = os.path.getsize(path)
    start = urllib.request.Request(
        f"{API}/upload/v1beta/files?key={key}", method="POST",
        data=json.dumps({"file": {"display_name": os.path.basename(path)}}).encode(),
        headers={"X-Goog-Upload-Protocol": "resumable", "X-Goog-Upload-Command": "start",
                 "X-Goog-Upload-Header-Content-Length": str(size), "X-Goog-Upload-Header-Content-Type": mime,
                 "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(start, timeout=120) as r:
            up_url = r.headers.get("X-Goog-Upload-URL") or r.headers.get("x-goog-upload-url")
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"업로드 시작 실패 {e.code}: {e.read().decode('utf-8','replace')[:500]}")
    with open(path, "rb") as f:
        body = f.read()
    info = _req("POST", up_url, data=body, headers={"Content-Length": str(size), "X-Goog-Upload-Offset": "0",
                                                     "X-Goog-Upload-Command": "upload, finalize"})
    fobj = info["file"]
    for _ in range(90):
        if fobj.get("state") == "ACTIVE":
            return fobj
        if fobj.get("state") == "FAILED":
            raise RuntimeError("Gemini가 영상 처리에 실패했어요.")
        time.sleep(2)
        fobj = _req("GET", f"{API}/v1beta/{fobj['name']}?key={key}")
    raise RuntimeError("영상 처리 대기 시간이 너무 길어요.")

DOODLES = ["sparkle", "heart", "motion", "arrow", "tear", "music", "zzz", "star", "ribbon", "paw", "lightning",
           "snowflake", "cloud", "exclaim", "question", "sweat", "bone", "flower", "moon", "bubbles"]

PLAN_SCHEMA = {
  "type": "OBJECT",
  "properties": {
    "product": {"type": "STRING"},
    "product_color": {"type": "STRING", "description": "제품 대표색 HEX, 예: #FF7A2F"},
    "segments": {"type": "ARRAY", "items": {"type": "OBJECT", "properties": {
        "start": {"type": "NUMBER"}, "end": {"type": "NUMBER"}, "why": {"type": "STRING"}}, "required": ["start", "end"]}},
    "subtitles": {"type": "ARRAY", "items": {"type": "STRING"}},
    "thumbnail_time": {"type": "NUMBER"},
    "thumbnail_text_position": {"type": "STRING", "enum": ["top", "middle", "bottom"]},
    "thumbnail_style": {"type": "STRING", "enum": ["product", "sticker", "character_scene", "product_scene"]},
    "character_action": {"type": "STRING"},
    "scene_place": {"type": "STRING"},
    "cover_bubble": {"type": "STRING"},
    "cover_emojis": {"type": "ARRAY", "items": {"type": "STRING"}},
    "cover_big_lines": {"type": "ARRAY", "items": {"type": "STRING"}},
    "cover_mood": {"type": "STRING", "enum": ["cute", "funny", "surprise", "cozy", "cool", "sad"]},
    "cover_sub_color": {"type": "STRING"},
    "thumbnail_product_box": {"type": "ARRAY", "items": {"type": "NUMBER"}},
    "cover_small": {"type": "STRING"},
    "cover_big": {"type": "STRING"},
    "cover_accent": {"type": "STRING"},
    "doodles": {"type": "ARRAY", "items": {"type": "STRING", "enum": DOODLES}},
    "caption": {"type": "STRING"},
    "hashtags": {"type": "ARRAY", "items": {"type": "STRING"}},
    "coupang_keywords": {"type": "ARRAY", "items": {"type": "STRING"}},
    "title": {"type": "STRING"},
  },
  "required": ["product", "product_color", "segments", "subtitles", "thumbnail_time", "thumbnail_style", "cover_small", "cover_big",
               "cover_accent", "doodles", "caption", "hashtags", "coupang_keywords", "title"],
}

def build_prompt(s, dur):
    mn, mx = s.get("min_seconds", 5), s.get("max_seconds", 10)
    has_char = bool(my_character(s))
    char_rule = ("내 캐릭터 사진이 등록돼 있어. sticker·character_scene도 쓸 수 있어." if has_char
                 else "내 캐릭터 사진이 없어. sticker·character_scene은 쓰지 마.")
    return f"""너는 인스타 신박템 릴스 채널의 편집자 겸 작가 '{s['persona_name']}'야.
캐릭터: {s['persona_desc']}

첨부한 원본 제품 영상(길이 {dur:.1f}초)을 보고, 아래 스타일로 편집 계획을 JSON으로만 답해.

[편집 스타일]
- 완성 길이는 {mn}~{mx}초 사이에서 영상 내용에 맞게 정한다. 보여줄 게 단순하면 짧게(5~6초), 변신·과정·반전이 있으면 길게(8~10초).
- 원본에서 구간 2~5개를 골라 이어 붙인다(각 0.8초 이상, 원본 범위 안). 자막 줄 수도 길이에 맞춘다(짧으면 3줄, 길면 4줄).
- 첫 구간은 3초 안에 '이게 뭐야?' 싶은 장면(독특한 생김새나 신박한 쓰임새가 바로 보이는 장면).
- 그다음 제품이 작동하거나 변신하는 장면, 마지막은 결과·완성 장면.
- 중요: 원본 화면에 글자(자막, 안내 문구, 외국어 설명, 워터마크)가 보이는 구간은 segments와 thumbnail_time에서 반드시 뺀다. 특히 영상 처음 몇 초에 뜨는 안내 문구를 주의한다.
- 사람 얼굴이 크게 나오는 구간도 뺀다.

[말투 규칙] ㅋㅋㅋ·ㅠㅠ는 자막 전체에서 1번, 썸네일 큰 줄에는 꼭 필요할 때만. 매 문장을 ㅋㅋ로 끝내지 마.
예시채널 실제 썸네일 문구(이 느낌으로): '결국 방치된 워치ㅠㅠ', '솔직히 너무 귀엽잖아ㅋㅋㅋ', '여기에 정착함', '다들 허리 펴고 1700만원 아끼자',
'알람 들은 내 표정', '열일하는 오브제', '출근 메이트', '소원 이뤄지는 거래', '입으면 덥고 벗으면 추울 때' (12개 중 ㅋㅋ·ㅠㅠ는 3개뿐).

[자막] 3~4줄. 한 줄씩 순서대로 화면에 뜬다. 줄마다 18자 안팎, 최대 22자.
- 1줄: 상황·공감 (예: 맨날 차는 거 까먹어서 방치된 워치 ㅠㅠ)
- 2~3줄: 제품으로 생긴 일 (예: 버리긴 아까워서 케이스에 꽂아둠)
- 마지막 줄: 감정 마무리, 끝에 이모지 1개 가능 (예: 볼 때마다 묘하게 정듦 🎀)
- 캐릭터 말투(반말). 제품 사양·가격·효능 설명 금지. 광고 말투 금지.
- 문구 유형은 하나 골라 쓴다: 상황 고백 / 주변 반응 / 숫자 농담 / 공감 순간 / 결과 선언 / 방법 소개

[썸네일]
- thumbnail_time: 원본 기준 초. 화면에 글자가 하나도 없고, 제품이 크게 또렷하게 보이고, 위쪽(또는 아래쪽)에 글자 넣을 빈 공간이 있는 순간.
- thumbnail_text_position: 글자를 넣을 자리. 제품이 아래쪽이면 top, 위쪽이면 bottom, 위아래로 꽉 차 있고 가운데가 비어 있으면 middle.
- thumbnail_style (썸네일 방식, 하나):
  product = 영상 장면에 제품이 크고 예쁘게 보일 때 (기본, 대부분 이것)
  sticker = 영상 장면은 좋은데 놀람·귀여움 같은 감정 반응이 핵심이라 내 캐릭터 리액션 스티커가 어울릴 때
  character_scene = 모자·옷·액세서리·머리핀·가방 키링처럼 착용하거나, 사람이 직접 써야 매력이 보이는 제품 (AI로 새 사진을 만듦)
  product_scene = 영상 장면이 어둡거나 지저분하거나 글자가 많아 썸네일로 쓸 장면이 없을 때 (AI로 제품 연출컷을 만듦)
  {char_rule}
- character_action: character_scene·product_scene일 때 그 사진의 연출 한 줄 (예: '오리 모자를 쓰고 거울 셀카, 깜짝 놀란 표정'). 아니면 빈 문자열.
- scene_place: 그 사진의 장소 (예: '햇살 드는 원룸 침대 위'). 아니면 빈 문자열.
- cover_small: 작은 줄(상황) 8~14자. cover_big: 큰 줄(결과·반응) 6~12자. cover_accent: cover_big 안의 강조 단어 1개(그대로 포함될 것).
- cover_big_lines: cover_big을 두 줄로 나눌 때의 줄바꿈. 의미 단위로 나누고 강조 단어는 끊지 마 (예: ['손이', '안 멈춤'] O, ['손이 안', '멈춤'] X). 짧으면 1줄.
- cover_mood: 문구 분위기 cute(귀여움)/funny(웃김)/surprise(놀람·신기)/cozy(포근·힐링)/cool(멋·기시기)/sad(애잔·현타) 중 하나. 스티커·낙서·글꼴이 여기에 맞춰진다.
- cover_sub_color: 낙서·스티커에 쓸 두 번째 색 HEX (제품·배경과 어울리는 색).
- thumbnail_product_box: thumbnail_time 장면에서 제품이 있는 위치 [ymin, xmin, ymax, xmax], 0~1000 기준. (제품을 크게 확대하는 데 씀)
- cover_bubble: 제품 옆 말풍선 반응 2~8자 (예: '헐 이게 돼?', '귀여워'). cover_emojis: 분위기에 맞는 이모지 1~2개.
- 색은 제품에 맞춘다: product_color는 제품의 가장 눈에 띄는 색(개구리=초록, 해파리=하늘색, 분홍 텀블러=분홍).
- doodles: 제품·상황에 맞는 낙서 3~5개 ({', '.join(DOODLES)} 중에서).
- product_color: 제품 대표색 HEX (강조 글자색으로 씀).

[글]
- caption: 캐릭터 말투 3문단(감정 고백 / 실제 사용 장면 / 자조·유머 마무리), 문단마다 1~2줄. 댓글 유도 문구는 넣지 마(따로 붙임).
- hashtags: 6~8개(# 포함). 광고·제휴 영상이므로 '내돈내산' 같은 직접 구매 표현은 쓰지 마. coupang_keywords: 쿠팡 검색어 3개. title: 유튜브 쇼츠용 제목 1줄(자막 1줄 느낌 + ㅋㅋㅋ).
- product: 제품 일반명.
모르는 건 추측하지 말고 가장 그럴듯한 것을 쓰되, 영상에 보이는 것만 근거로 해."""

WEB_FORMAT = """

[출력 형식] 아래 키를 가진 JSON 하나만 답해. 설명 문장 없이:
product, product_color, segments([{start,end,why}]), subtitles([..]), thumbnail_time, thumbnail_text_position(top/middle/bottom),
thumbnail_style(product/sticker/character_scene/product_scene), character_action, scene_place, thumbnail_product_box([ymin,xmin,ymax,xmax]),
cover_small, cover_big, cover_big_lines([..]), cover_accent, cover_mood, cover_sub_color, cover_bubble, cover_emojis([..]), doodles([..]),
caption, hashtags([..]), coupang_keywords([..]), title"""

def web_prompt(s, dur):
    """API 없이 Gemini 웹에 붙여넣을 프롬프트"""
    return build_prompt(s, dur) + WEB_FORMAT

def parse_plan_text(text):
    """Gemini 웹 답변(코드블록·앞뒤 문장 포함 가능)에서 JSON만 꺼낸다"""
    t = text.strip().replace("\u201c", '"').replace("\u201d", '"')
    t = re.sub(r"```(?:json)?", "", t)
    a, b = t.find("{"), t.rfind("}")
    if a < 0 or b <= a:
        raise ValueError("답변에서 JSON을 찾지 못했어요. Gemini 답변 전체를 그대로 붙여넣어 주세요.")
    body = re.sub(r",\s*([}\]])", r"\1", t[a:b + 1])
    plan = json.loads(body)
    miss = [k for k in ("segments", "subtitles", "cover_big") if k not in plan]
    if miss:
        raise ValueError("답변에 빠진 항목이 있어요: " + ", ".join(miss))
    plan.setdefault("product", ""); plan.setdefault("product_color", "#FF7A2F")
    plan.setdefault("thumbnail_time", 1.0); plan.setdefault("cover_small", "")
    plan.setdefault("cover_accent", ""); plan.setdefault("doodles", ["sparkle", "heart"])
    plan.setdefault("caption", ""); plan.setdefault("hashtags", []); plan.setdefault("coupang_keywords", [])
    plan.setdefault("title", "")
    return plan

def prepare_web(src, outroot):
    """Gemini 웹에 올릴 가벼운 영상을 만들고 경로·길이를 돌려준다"""
    name = os.path.splitext(os.path.basename(src))[0]
    outdir = os.path.join(outroot, name); os.makedirs(outdir, exist_ok=True)
    proxy = os.path.join(outdir, "Gemini에_올릴_영상.mp4")
    make_proxy(src, proxy)
    return proxy, probe(src)["duration"]

def gemini_plan(s, video_path, dur):
    key = s.get("api_key", "").strip()
    if not key:
        raise RuntimeError("Gemini API 키가 없어요. 설정에서 넣어주세요 (aistudio.google.com 에서 무료 발급).")
    model = s.get("model", "auto")
    if not model or model == "auto":
        model = pick_model(key)
    log(f"  - Gemini 모델: {model}")
    log("  - 영상 업로드 중...")
    f = upload_file(key, video_path)
    body = {
        "contents": [{"role": "user", "parts": [
            {"file_data": {"mime_type": f.get("mimeType", "video/mp4"), "file_uri": f["uri"]}},
            {"text": build_prompt(s, dur)}]}],
        "generationConfig": {"responseMimeType": "application/json", "responseSchema": PLAN_SCHEMA, "temperature": 0.8},
    }
    last = None
    for attempt in range(3):
        try:
            log("  - 분석 중...")
            r = _req("POST", f"{API}/v1beta/models/{model}:generateContent?key={key}",
                     data=json.dumps(body).encode("utf-8"), headers={"Content-Type": "application/json"})
            txt = r["candidates"][0]["content"]["parts"][0]["text"]
            plan = json.loads(txt)
            plan["_model"] = model
            try:
                _req("DELETE", f"{API}/v1beta/{f['name']}?key={key}", raw=True)
            except Exception:
                pass
            return plan
        except Exception as e:
            last = e
            msg = str(e)
            wait = 30 if "429" in msg else 5
            log(f"  - 재시도 ({attempt+1}/3): {msg[:160]}")
            time.sleep(wait)
    raise RuntimeError(f"Gemini 분석 실패: {last}")

# ---------------------------------------------------------------- plan 정리
def sanitize_plan(plan, dur, s):
    segs = []
    for sg in plan.get("segments", []):
        try:
            a, b = float(sg["start"]), float(sg["end"])
        except Exception:
            continue
        a, b = max(0.0, a), min(dur, b)
        if b - a >= 0.4:
            segs.append({"start": round(a, 2), "end": round(b, 2)})
    if not segs:
        t = min(dur, 7)
        segs = [{"start": 0.0, "end": round(t, 2)}]
    segs.sort(key=lambda x: x["start"])
    total = sum(x["end"] - x["start"] for x in segs)
    want = min(s.get("min_seconds", 5), dur)
    if total < want:
        # 너무 짧으면 각 구간 끝을 다음 구간 전까지 늘리고, 그래도 모자라면 앞으로 늘린다
        need = want - total
        for i, sg in enumerate(segs):
            room = (segs[i + 1]["start"] if i + 1 < len(segs) else dur) - sg["end"]
            add = min(room, need / (len(segs) - i))
            sg["end"] = round(sg["end"] + max(0, add), 2); need -= max(0, add)
        for i, sg in enumerate(segs):
            if need <= 0: break
            room = sg["start"] - (segs[i - 1]["end"] if i > 0 else 0.0)
            add = min(room, need)
            sg["start"] = round(sg["start"] - max(0, add), 2); need -= max(0, add)
        total = sum(x["end"] - x["start"] for x in segs)
    cap = s.get("max_seconds", 10)
    while total > cap and len(segs) > 1:
        segs.pop()
        total = sum(x["end"] - x["start"] for x in segs)
    if total > cap:
        segs[0]["end"] = round(segs[0]["start"] + cap, 2)
    plan["segments"] = segs
    subs = [x.strip() for x in plan.get("subtitles", []) if x and x.strip()][:4]
    plan["subtitles"] = subs or ["(자막 없음)"]
    tt = float(plan.get("thumbnail_time", segs[0]["start"] + 0.5))
    plan["thumbnail_time"] = min(max(0.0, tt), max(0.0, dur - 0.05))
    if plan.get("thumbnail_text_position") not in TEXT_POS:
        plan["thumbnail_text_position"] = "top"
    st = plan.get("thumbnail_style")
    if st not in THUMB_STYLES:
        st = "product"
    if st in ("sticker", "character_scene") and not my_character(s, plan):
        st = "product" if st == "sticker" else "product_scene"
    plan["thumbnail_style"] = st
    plan["cover_bubble"] = (plan.get("cover_bubble") or "").strip()[:10]
    plan["cover_emojis"] = [e for e in (plan.get("cover_emojis") or []) if isinstance(e, str) and e.strip()][:2]
    plan.setdefault("character_action", ""); plan.setdefault("scene_place", "")
    if plan.get("cover_mood") not in MOODS:
        plan["cover_mood"] = "cute"
    bl = plan.get("cover_big_lines")
    plan["cover_big_lines"] = [x for x in bl if isinstance(x, str) and x.strip()][:2] if isinstance(bl, list) else []
    if plan.get("cover_accent") and plan["cover_accent"] not in plan.get("cover_big", ""):
        plan["cover_accent"] = ""
    plan["doodles"] = [d for d in plan.get("doodles", []) if d in DOODLES][:4] or ["sparkle", "motion"]
    banned = ("내돈내산", "내돈주고", "직접구매")
    plan["hashtags"] = [h for h in plan.get("hashtags", []) if not any(b in h for b in banned)]
    if not re.match(r"^#?[0-9a-fA-F]{6}$", plan.get("product_color", "") or ""):
        plan["product_color"] = "#FF7A2F"
    if not plan["product_color"].startswith("#"):
        plan["product_color"] = "#" + plan["product_color"]
    return plan

# ---------------------------------------------------------------- 그리기 공통
from PIL import Image, ImageDraw, ImageFont, ImageFilter

EMOJI_RE = re.compile("[\U0001F000-\U0001FAFF\u2600-\u27BF\uFE0F\u200d\u2B50\u2764]+")

def font(name, size):
    p = os.path.join(FONT_DIR, name)
    if not os.path.exists(p):
        p = r"C:\Windows\Fonts\malgunbd.ttf"
    return ImageFont.truetype(p, size)

def emoji_font(size):
    for p in (r"C:\Windows\Fonts\seguiemj.ttf", "/System/Library/Fonts/Apple Color Emoji.ttc"):
        if os.path.exists(p):
            try:
                return ImageFont.truetype(p, size)
            except Exception:
                pass
    return None

def split_runs(text):
    runs, pos = [], 0
    for m in EMOJI_RE.finditer(text):
        if m.start() > pos:
            runs.append((text[pos:m.start()], False))
        runs.append((m.group(), True))
        pos = m.end()
    if pos < len(text):
        runs.append((text[pos:], False))
    return runs

def hex2rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

# ---------------------------------------------------------------- 자막 PNG
FONT_LABELS = {
    "Jua-Regular.ttf": "주아 (둥글고 굵음, 기본)", "Pretendard-ExtraBold.otf": "프리텐다드 엑스트라볼드",
    "Pretendard-Black.otf": "프리텐다드 블랙", "DoHyeon-Regular.ttf": "도현 (각진 굵음)",
    "BlackHanSans-Regular.ttf": "검은고딕 (아주 굵음)", "GothicA1-Black.ttf": "고딕A1 블랙",
    "NanumGothic-ExtraBold.ttf": "나눔고딕 엑스트라볼드", "Sunflower-Bold.ttf": "해바라기 볼드",
    "GowunDodum-Regular.ttf": "고운돋움 (부드러운)", "BagelFatOne-Regular.ttf": "베이글팻원 (말랑 통통)",
    "Dongle-Bold.ttf": "동글 볼드 (귀여운)", "Gaegu-Bold.ttf": "개구 볼드 (손글씨)",
    "NanumPenScript-Regular.ttf": "나눔펜 (손글씨)", "YeonSung-Regular.ttf": "연성 (붓펜)", "SingleDay-Regular.ttf": "싱글데이 (귀여운)",
}

def list_fonts():
    """fonts 폴더의 폰트 목록 {보이는 이름: 파일}. 눈누 등에서 받은 폰트를 fonts 폴더에 넣으면 같이 나와요"""
    out = {}
    for fn in sorted(os.listdir(FONT_DIR)):
        if fn.lower().endswith((".ttf", ".otf")):
            out[FONT_LABELS.get(fn, os.path.splitext(fn)[0])] = fn
    order = [FONT_LABELS[k] for k in FONT_LABELS if FONT_LABELS[k] in out]
    return {k: out[k] for k in order + [k for k in out if k not in order]}

def render_subtitle(text, s, W=1080, H=220):
    fname = s.get("sub_font", "Jua-Regular.ttf")
    if not os.path.exists(os.path.join(FONT_DIR, fname)): fname = "Jua-Regular.ttf"
    k = font_scale(fname)
    size = int(58 * k)
    while True:
        f = font(fname, size); ef = emoji_font(int(size / k * 0.9))
        runs = split_runs(text)
        widths = []
        for t, is_e in runs:
            fnt = ef if (is_e and ef) else f
            widths.append(fnt.getlength(t) if not is_e or ef else 0)
        total = sum(widths) + 8
        if total <= W * 0.88 or size <= int(34 * k):
            break
        size -= 2
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    shadow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    sd = ImageDraw.Draw(shadow); d = ImageDraw.Draw(img)
    x = (W - total) / 2; y = H / 2
    stroke = max(3, size // 14)
    for (t, is_e), w in zip(runs, widths):
        if is_e:
            if ef:
                d.text((x + 6, y), t, font=ef, anchor="lm", embedded_color=True)
            x += w + 6
            continue
        sd.text((x + 2, y + 4), t, font=f, anchor="lm", fill=(0, 0, 0, 170), stroke_width=stroke + 1, stroke_fill=(0, 0, 0, 170))
        d.text((x, y), t, font=f, anchor="lm", fill=(255, 255, 255, 255), stroke_width=stroke, stroke_fill=(20, 20, 20, 255))
        x += w
    shadow = shadow.filter(ImageFilter.GaussianBlur(4))
    return Image.alpha_composite(shadow, img)

def render_ad_label(W=1080, H=1920):
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    f = font("Jua-Regular.ttf", 40)
    d.text((W - 60, 70), "[광고]", font=f, anchor="rt", fill=(235, 235, 235, 190), stroke_width=2, stroke_fill=(90, 90, 90, 150))
    return img

# ---------------------------------------------------------------- 썸네일
DOODLE_KINDS = ["sparkle", "heart", "motion", "arrow", "tear", "music", "zzz", "star", "ribbon", "paw", "lightning",
                "snowflake", "cloud", "exclaim", "question", "sweat", "bone", "flower", "moon", "bubbles"]
MOODS = {  # 멘트 분위기 → 기본 꾸미기 세트
    "cute": ["heart", "sparkle", "ribbon", "flower"],
    "funny": ["sweat", "exclaim", "motion", "sparkle"],
    "surprise": ["exclaim", "question", "lightning", "sparkle"],
    "cozy": ["star", "moon", "cloud", "sparkle"],
    "cool": ["lightning", "music", "arrow", "sparkle"],
    "sad": ["tear", "sweat", "cloud", "heart"],
}
MOOD_BIG_FONT = {"cute": "BagelFatOne-Regular.ttf", "cozy": "BagelFatOne-Regular.ttf", "funny": "Jua-Regular.ttf",
                 "surprise": "Jua-Regular.ttf", "cool": "BlackHanSans-Regular.ttf", "sad": "Jua-Regular.ttf"}
YELLOW = (255, 214, 90)

def _mix(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))

def vivid(rgb):
    """너무 연하거나 탁한 제품 색을 같은 계열의 선명한 색으로"""
    import colorsys
    h, s_, v = colorsys.rgb_to_hsv(*[c / 255 for c in rgb])
    if s_ < 0.08:                      # 흰색·회색 제품은 기본 주황 계열로
        h, s_ = 0.07, 0.75
    s_ = max(s_, 0.62); v = min(max(v, 0.62), 0.95)
    return tuple(int(c * 255) for c in colorsys.hsv_to_rgb(h, s_, v))

def thumb_palette(plan):
    acc = vivid(hex2rgb(plan.get("product_color", "#FF7A2F")))
    sub = plan.get("cover_sub_color")
    sub = hex2rgb(sub) if sub and re.match(r"^#?[0-9a-fA-F]{6}$", sub) else _mix(YELLOW, acc, 0.25)
    deep = _mix(acc, (45, 25, 20), 0.62)          # 큰 글자 외곽선 = 제품 색의 진한 톤
    ink = _mix(acc, (35, 20, 15), 0.82)           # 강조 아닌 글자 색
    return {"acc": acc, "light": _mix(acc, (255, 255, 255), 0.5), "pastel": _mix(acc, (255, 250, 240), 0.84),
            "deep": deep, "ink": ink, "sub": sub, "white": (255, 255, 255), "yellow": YELLOW}

def draw_doodle(d, kind, cx, cy, sc, color, outline=(60, 40, 30)):
    w = max(3, int(5 * sc)); o = outline
    if kind in ("sparkle", "star"):
        r = 34 * sc; n = 4 if kind == "sparkle" else 5; pts = []
        for i in range(n * 2):
            ang = math.pi * i / n - math.pi / 2; rr = r if i % 2 == 0 else r * (0.28 if kind == "sparkle" else 0.45)
            pts.append((cx + rr * math.cos(ang), cy + rr * math.sin(ang)))
        d.polygon(pts, fill=color, outline=o, width=max(2, w // 2))
    elif kind == "heart":
        r = 26 * sc
        d.ellipse((cx - r, cy - r * 0.9, cx, cy + r * 0.1), fill=color, outline=o, width=max(2, w // 2))
        d.ellipse((cx, cy - r * 0.9, cx + r, cy + r * 0.1), fill=color, outline=o, width=max(2, w // 2))
        d.polygon([(cx - r * 0.97, cy - r * 0.25), (cx + r * 0.97, cy - r * 0.25), (cx, cy + r * 1.1)], fill=color)
    elif kind == "motion":
        for i in range(3):
            a = -0.6 + i * 0.6; l = 40 * sc
            x0 = cx + math.cos(a) * 20 * sc; y0 = cy + math.sin(a) * 20 * sc
            d.line((x0, y0, x0 + math.cos(a) * l, y0 + math.sin(a) * l), fill=color, width=w * 2)
    elif kind == "arrow":
        pts = [(cx - 70 * sc + 140 * sc * t, cy - 50 * sc * math.sin(math.pi * t)) for t in [i / 20 for i in range(21)]]
        d.line(pts, fill=color, width=w * 2, joint="curve"); ex, ey = pts[-1]
        d.polygon([(ex + 8 * sc, ey + 16 * sc), (ex - 22 * sc, ey + 4 * sc), (ex + 2 * sc, ey - 20 * sc)], fill=color)
    elif kind in ("tear", "sweat"):
        r = 15 * sc; c = (120, 190, 255) if kind == "tear" else (150, 210, 255)
        for k, (dx, dy) in enumerate([(0, 0), (30 * sc, 22 * sc)] if kind == "sweat" else [(0, 0)]):
            x, y = cx + dx, cy + dy; rr = r * (1 - 0.3 * k)
            d.polygon([(x - rr * 0.9, y - rr * 0.3), (x + rr * 0.9, y - rr * 0.3), (x, y - rr * 2.3)], fill=c, outline=o)
            d.ellipse((x - rr, y - rr, x + rr, y + rr), fill=c, outline=o, width=max(2, w // 2))
    elif kind == "music":
        r = 14 * sc; st = 40 * sc; hx, hy = cx - 12 * sc, cy + 18 * sc
        d.ellipse((hx - r * 1.2, hy - r, hx + r * 1.2, hy + r), fill=color, outline=o, width=max(2, w // 2))
        d.line((hx + r * 1.1, hy, hx + r * 1.1, hy - st), fill=o, width=w + 2)
        d.polygon([(hx + r * 1.1, hy - st), (hx + r * 1.1 + 20 * sc, hy - st + 12 * sc), (hx + r * 1.1 + 20 * sc, hy - st + 24 * sc), (hx + r * 1.1, hy - st + 12 * sc)], fill=color, outline=o)
    elif kind == "zzz":
        f = font("Jua-Regular.ttf", int(54 * sc))
        d.text((cx, cy), "z z Z", font=f, anchor="mm", fill=color, stroke_width=max(2, w // 2), stroke_fill=o)
    elif kind == "ribbon":
        r = 24 * sc
        d.polygon([(cx, cy), (cx - r * 1.6, cy - r), (cx - r * 1.6, cy + r)], fill=color, outline=o)
        d.polygon([(cx, cy), (cx + r * 1.6, cy - r), (cx + r * 1.6, cy + r)], fill=color, outline=o)
        d.ellipse((cx - r * 0.4, cy - r * 0.4, cx + r * 0.4, cy + r * 0.4), fill=color, outline=o, width=2)
        d.line((cx - 4 * sc, cy, cx - 18 * sc, cy + r * 1.7), fill=o, width=w); d.line((cx + 4 * sc, cy, cx + 18 * sc, cy + r * 1.7), fill=o, width=w)
    elif kind == "paw":
        r = 16 * sc
        d.ellipse((cx - r * 1.2, cy - r * 0.4, cx + r * 1.2, cy + r * 1.4), fill=color, outline=o, width=max(2, w // 2))
        for dx, dy in [(-1.3, -1.1), (-0.45, -1.7), (0.45, -1.7), (1.3, -1.1)]:
            d.ellipse((cx + dx * r - r * 0.42, cy + dy * r - r * 0.5, cx + dx * r + r * 0.42, cy + dy * r + r * 0.5), fill=color, outline=o, width=2)
    elif kind == "lightning":
        s_ = 30 * sc
        d.polygon([(cx + s_ * 0.2, cy - s_ * 1.2), (cx - s_ * 0.6, cy + s_ * 0.15), (cx - s_ * 0.05, cy + s_ * 0.15),
                   (cx - s_ * 0.35, cy + s_ * 1.2), (cx + s_ * 0.6, cy - s_ * 0.2), (cx + s_ * 0.05, cy - s_ * 0.2)], fill=color, outline=o, width=max(2, w // 2))
    elif kind == "snowflake":
        r = 28 * sc
        for k in range(3):
            a = math.pi * k / 3
            d.line((cx - r * math.cos(a), cy - r * math.sin(a), cx + r * math.cos(a), cy + r * math.sin(a)), fill=color, width=w)
    elif kind == "cloud":
        r = 20 * sc
        for dx, dy, rr in [(-1.1, 0.2, 0.8), (0, -0.3, 1.0), (1.1, 0.2, 0.8)]:
            d.ellipse((cx + dx * r - rr * r, cy + dy * r - rr * r, cx + dx * r + rr * r, cy + dy * r + rr * r), fill=color, outline=o, width=max(2, w // 2))
        for dx, dy, rr in [(-1.1, 0.2, 0.8), (0, -0.3, 1.0), (1.1, 0.2, 0.8)]:
            d.ellipse((cx + dx * r - rr * r + 3, cy + dy * r - rr * r + 3, cx + dx * r + rr * r - 3, cy + dy * r + rr * r - 3), fill=color)
    elif kind in ("exclaim", "question"):
        f = font("BlackHanSans-Regular.ttf", int(78 * sc))
        d.text((cx, cy), "!!" if kind == "exclaim" else "?!", font=f, anchor="mm", fill=color, stroke_width=max(3, w), stroke_fill=o)
    elif kind == "bone":
        r = 12 * sc; L = 34 * sc
        d.rounded_rectangle((cx - L, cy - r * 0.7, cx + L, cy + r * 0.7), radius=r * 0.7, fill=color, outline=o, width=2)
        for sx in (-1, 1):
            for sy in (-1, 1):
                d.ellipse((cx + sx * L - r, cy + sy * r * 0.8 - r, cx + sx * L + r, cy + sy * r * 0.8 + r), fill=color, outline=o, width=2)
    elif kind == "flower":
        r = 14 * sc
        for k in range(5):
            a = 2 * math.pi * k / 5
            x, y = cx + math.cos(a) * r * 1.2, cy + math.sin(a) * r * 1.2
            d.ellipse((x - r, y - r, x + r, y + r), fill=color, outline=o, width=2)
        d.ellipse((cx - r * 0.7, cy - r * 0.7, cx + r * 0.7, cy + r * 0.7), fill=YELLOW, outline=o, width=2)
    elif kind == "moon":
        r = 28 * sc
        d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=color, outline=o, width=max(2, w // 2))
        d.ellipse((cx - r * 0.35, cy - r * 1.05, cx + r * 1.25, cy + r * 0.55), fill=(0, 0, 0, 0))
    elif kind == "bubbles":
        for dx, dy, rr in [(0, 0, 14), (26, -20, 9), (40, 8, 6)]:
            d.ellipse((cx + dx * sc - rr * sc, cy + dy * sc - rr * sc, cx + dx * sc + rr * sc, cy + dy * sc + rr * sc), outline=color, width=w)

def gradient_text_layer(size, text, fnt, pos, c1, c2):
    W, H = size
    mask = Image.new("L", (W, H), 0)
    ImageDraw.Draw(mask).text(pos, text, font=fnt, fill=255)
    bbox = mask.getbbox() or (0, 0, W, H)
    grad = Image.new("RGBA", (W, H)); gd = ImageDraw.Draw(grad)
    y0, y1 = bbox[1], max(bbox[3], bbox[1] + 1)
    for y in range(H):
        t = min(1, max(0, (y - y0) / (y1 - y0)))
        gd.line((0, y, W, y), fill=_mix(c1, c2, t) + (255,))
    out = Image.new("RGBA", (W, H), (0, 0, 0, 0)); out.paste(grad, (0, 0), mask)
    return out

LAUGH_RE = re.compile(r"[ㅋㅎㅠㅜ]+$")

def split_big(text, acc, fnt, maxw, lines_hint=None):
    """큰 글자 줄바꿈: 의미 단위로, 강조 단어는 끊지 않고 둘째 줄 앞에, ㅋㅋ·ㅠㅠ는 마지막 줄에 붙인다"""
    if lines_hint:
        hint = [l.strip() for l in lines_hint if l and l.strip()][:2]
        if hint and "".join(hint).replace(" ", "") == text.replace(" ", ""):
            return hint
    if fnt.getlength(text) <= maxw:
        return [text]
    words = text.split(" ")
    if len(words) == 1:
        m = LAUGH_RE.search(text); core = text[:m.start()] if m else text
        mid = len(core) // 2
        return [core[:mid], core[mid:] + (m.group() if m else "")]
    best, bestv = None, 1e18
    ai = text.find(acc) if acc else -1
    for i in range(1, len(words)):
        a, b = " ".join(words[:i]), " ".join(words[i:])
        cut = len(a)
        score = abs(fnt.getlength(a) - fnt.getlength(b))
        if ai >= 0 and ai < cut < ai + len(acc):
            score += 10000                       # 강조 단어가 잘리면 크게 감점
        if ai >= 0 and cut + 1 == ai:
            score -= 300                         # 강조 단어로 둘째 줄 시작하면 가점
        if max(fnt.getlength(a), fnt.getlength(b)) > maxw:
            score += 3000
        if score < bestv:
            best, bestv = [a, b], score
    return best

def font_scale(name):
    """폰트마다 실제 글자 크기가 달라서, '가' 높이가 비슷해지도록 보정"""
    f = font(name, 100); bb = f.getbbox("가")
    h = max(1, bb[3] - bb[1])
    return min(1.9, max(0.75, 78.0 / h))

THUMB_STYLES = {"product": "영상 장면", "sticker": "영상 장면 + 캐릭터 스티커",
                "character_scene": "AI 연출: 캐릭터 등장", "product_scene": "AI 연출: 제품 연출컷"}
AI_STYLES = ("character_scene", "product_scene")
SAFE_TOP, SAFE_BOTTOM = 0.15, 0.80   # 인스타 프로필 격자(3:4)와 릴스 하단 UI에 안 잘리는 구역
TEXT_POS = ("top", "middle", "bottom")

def pop_image(im):
    from PIL import ImageEnhance
    im = ImageEnhance.Color(im).enhance(1.2)
    im = ImageEnhance.Contrast(im).enhance(1.06)
    im = ImageEnhance.Brightness(im).enhance(1.05)
    im = ImageEnhance.Sharpness(im).enhance(1.3)
    r, g, b = im.split()
    r = r.point(lambda v: min(255, int(v * 1.03))); b = b.point(lambda v: int(v * 0.97))
    return Image.merge("RGB", (r, g, b))

def _band_energy(im, y0, y1):
    from PIL import ImageStat
    g = im.convert("L").resize((108, 192)).filter(ImageFilter.FIND_EDGES)
    return ImageStat.Stat(g.crop((0, int(y0 * 192), 108, max(int(y0 * 192) + 1, int(y1 * 192))))).mean[0]

def _skin_ratio(im, y0, y1):
    sm = im.convert("YCbCr").resize((108, 192)).crop((0, int(y0 * 192), 108, max(int(y0 * 192) + 1, int(y1 * 192))))
    px = list(sm.getdata())
    return sum(1 for (y, cb, cr) in px if 80 < y < 250 and 85 <= cb <= 130 and 135 <= cr <= 175) / max(1, len(px))

def _box_overlap(box, y0, y1):
    if not box: return 0.0
    by0, by1 = box[1], box[3]
    return max(0.0, min(by1, y1) - max(by0, y0)) / max(1e-6, by1 - by0)

def choose_text_band(im, hint, box=None):
    bands = {"top": (SAFE_TOP, SAFE_TOP + 0.28), "middle": (0.38, 0.62), "bottom": (SAFE_BOTTOM - 0.28, SAFE_BOTTOM)}
    e = {k: (_band_energy(im, *v) + 1) * (1 + 6 * _skin_ratio(im, *v)) * (1 + 3 * _box_overlap(box, *v)) for k, v in bands.items()}
    if hint in e and e[hint] <= min(e.values()) * 1.6:
        return hint
    return min(e, key=e.get)

def _norm_box(plan):
    """Gemini가 준 제품 위치 [ymin,xmin,ymax,xmax] (0~1000) → (x0,y0,x1,y1) 0~1"""
    b = plan.get("thumbnail_product_box")
    try:
        ymin, xmin, ymax, xmax = [float(v) for v in b][:4]
        if max(ymin, xmin, ymax, xmax) > 1.5:
            ymin, xmin, ymax, xmax = [v / 1000 for v in (ymin, xmin, ymax, xmax)]
        if xmax - xmin < 0.03 or ymax - ymin < 0.03:
            return None
        return (max(0, xmin), max(0, ymin), min(1, xmax), min(1, ymax))
    except Exception:
        return None

def frame_to_916(src_im, box, band_hint):
    """9:16로 자르면서, 제품이 작으면 확대해서 크게 보이게(최대 1.7배). 제품은 글자 반대쪽에 오도록"""
    W, H = 1080, 1920
    iw, ih = src_im.size
    base_h = min(ih, iw * 16 / 9); base_w = base_h * 9 / 16
    zoom = 1.0
    if box:
        pw = (box[2] - box[0]) * iw; ph = (box[3] - box[1]) * ih
        zoom = max(1.0, min(1.7, max(0.62 * base_w / max(pw, 1), 0.40 * base_h / max(ph, 1))))
        if band_hint in ("top", "bottom"):
            zoom = min(zoom, max(1.0, 0.44 * base_h / max(ph, 1)))   # 제품이 글자 자리까지 커지지 않게
    cw, ch = base_w / zoom, base_h / zoom
    if box:
        cx = (box[0] + box[2]) / 2 * iw; cy = (box[1] + box[3]) / 2 * ih
        ph_c = (box[3] - box[1]) * ih / ch           # 자른 화면에서 제품 높이 비율
        if band_hint == "top":
            target_y = min(0.47 + ph_c / 2, 0.93 - ph_c / 2)      # 제품 윗면이 글자 아래(47%)에서 시작
        elif band_hint == "bottom":
            target_y = max(0.53 - ph_c / 2, 0.16 + ph_c / 2)      # 제품 아랫면이 글자 위(53%)에서 끝
        else:
            target_y = 0.5
        x0 = cx - cw / 2; y0 = cy - ch * target_y
    else:
        x0 = (iw - cw) / 2; y0 = (ih - ch) / 2
    x0 = min(max(0, x0), iw - cw); y0 = min(max(0, y0), ih - ch)
    crop = src_im.crop((int(x0), int(y0), int(x0 + cw), int(y0 + ch))).resize((W, H), Image.LANCZOS)
    nb = None
    if box:
        nb = ((box[0] * iw - x0) / cw, (box[1] * ih - y0) / ch, (box[2] * iw - x0) / cw, (box[3] * ih - y0) / ch)
    return crop, nb, zoom

def emoji_sticker(ch, size=110):
    ef = emoji_font(size)
    if not ef: return None
    pad = 24
    im = Image.new("RGBA", (size * 2 + pad * 2, size + pad * 2), (0, 0, 0, 0))
    ImageDraw.Draw(im).text((pad, pad + size // 2), ch, font=ef, anchor="lm", embedded_color=True)
    bb = im.getbbox()
    if not bb: return None
    im = im.crop((max(0, bb[0] - 14), max(0, bb[1] - 14), bb[2] + 14, bb[3] + 14))
    a = im.getchannel("A").point(lambda v: 255 if v > 30 else 0).filter(ImageFilter.MaxFilter(17))
    white = Image.new("RGBA", im.size, (255, 255, 255, 255)); white.putalpha(a)
    out = Image.new("RGBA", im.size, (0, 0, 0, 0)); out.alpha_composite(white); out.alpha_composite(im)
    return out

def speech_bubble(text, s, pal):
    f = font("Jua-Regular.ttf", 56)
    tw = f.getlength(text); w, h = int(tw + 70), 104
    im = Image.new("RGBA", (w + 20, h + 46), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle((4, 4, w, h), radius=48, fill=(255, 255, 255), outline=pal["deep"], width=6)
    d.polygon([(w * 0.28, h - 3), (w * 0.22, h + 38), (w * 0.42, h - 3)], fill=(255, 255, 255))
    d.line([(w * 0.28, h + 1), (w * 0.22, h + 38), (w * 0.42, h + 1)], fill=pal["deep"], width=6, joint="curve")
    d.text((w / 2 + 2, h / 2 + 4), text, font=f, anchor="mm", fill=pal["acc"], stroke_width=3, stroke_fill=pal["deep"])
    return im.rotate(-3, resample=Image.BICUBIC, expand=True)

def _text_block(plan, s, W, pal):
    mood = plan.get("cover_mood") if plan.get("cover_mood") in MOODS else "cute"
    big_font = MOOD_BIG_FONT.get(mood, "Jua-Regular.ttf")
    if not os.path.exists(os.path.join(FONT_DIR, big_font)): big_font = s.get("thumb_font", "Jua-Regular.ttf")
    layer = Image.new("RGBA", (W, 900), (0, 0, 0, 0)); d = ImageDraw.Draw(layer)
    by = 40
    small = plan.get("cover_small", "")
    label_box = None; y = by
    if small:
        fs = font("Jua-Regular.ttf", 60)
        tw = fs.getlength(small); bw = tw + 160; bx = (W - bw) / 2
        d.rounded_rectangle((bx + 7, by + 9, bx + bw + 7, by + 110), radius=54, fill=(0, 0, 0, 70))
        d.rounded_rectangle((bx, by, bx + bw, by + 104), radius=52, fill=pal["pastel"] + (255,), outline=pal["deep"], width=6)
        cx0, cy0 = bx + 40, by + 28
        icon = {"cute": "heart", "cozy": "star", "sad": "tear", "cool": "lightning"}.get(mood, "check")
        if icon == "check":
            d.rounded_rectangle((cx0, cy0, cx0 + 48, cy0 + 48), radius=11, fill=pal["acc"], outline=pal["deep"], width=4)
            d.line((cx0 + 10, cy0 + 25, cx0 + 21, cy0 + 36, cx0 + 39, cy0 + 12), fill=(255, 255, 255), width=7, joint="curve")
        else:
            draw_doodle(d, icon, cx0 + 24, cy0 + 26, 0.85, pal["acc"], outline=pal["deep"])
        d.text((bx + 106, by + 54), small, font=fs, anchor="lm", fill=pal["ink"])
        label_box = (bx, by, bx + bw, by + 104); y = by + 140
    big = plan.get("cover_big", ""); acc = plan.get("cover_accent", "")
    flags = [False] * len(big)
    if acc and acc in big:
        i0 = big.index(acc)
        for k in range(i0, i0 + len(acc)): flags[k] = True
    size = 178
    fb = font(big_font, size); lines = split_big(big, acc, fb, W - 100, plan.get("cover_big_lines"))
    while max(fb.getlength(l) for l in lines) > W - 90 and size > 100:
        size -= 6; fb = font(big_font, size); lines = split_big(big, acc, fb, W - 100, plan.get("cover_big_lines"))
    tl, tr = W, 0; pos = 0
    for line in lines:
        start = big.find(line, pos); start = pos if start < 0 else start
        lflags = flags[start:start + len(line)]; pos = start + len(line)
        lw = fb.getlength(line); x = (W - lw) / 2; tl, tr = min(tl, x), max(tr, x + lw)
        sh = Image.new("RGBA", layer.size, (0, 0, 0, 0))
        ImageDraw.Draw(sh).text((x + 6, y + 16), line, font=fb, fill=(0, 0, 0, 130), stroke_width=28, stroke_fill=(0, 0, 0, 130))
        layer.alpha_composite(sh.filter(ImageFilter.GaussianBlur(7)))
        d.text((x, y + 9), line, font=fb, fill=pal["deep"], stroke_width=28, stroke_fill=pal["deep"])
        d.text((x, y), line, font=fb, fill=pal["deep"], stroke_width=28, stroke_fill=pal["deep"])
        d.text((x, y), line, font=fb, fill=(255, 255, 255), stroke_width=14, stroke_fill=(255, 255, 255))
        parts = []
        for ch, fl in zip(line, lflags + [False] * (len(line) - len(lflags))):
            if parts and parts[-1][1] == fl: parts[-1] = (parts[-1][0] + ch, fl)
            else: parts.append((ch, fl))
        cx = x
        for t, is_acc in parts:
            if is_acc:
                layer.alpha_composite(gradient_text_layer(layer.size, t, fb, (cx, y), pal["light"], pal["acc"]))
            else:
                d.text((cx, y), t, font=fb, fill=pal["ink"])
            cx += fb.getlength(t)
        y += int(size * 1.06)
    return layer, label_box, (tl, tr), y + 30, mood

def render_thumbnail(frame_path, plan, s, out_path, allow_sticker=True, use_box=True):
    W, H = 1080, 1920
    src_im = Image.open(frame_path).convert("RGB")
    box = _norm_box(plan) if use_box else None
    hint = plan.get("thumbnail_text_position", "top")
    base, pbox, zoom = frame_to_916(src_im, box, hint)
    base = pop_image(base).convert("RGBA")
    plan["_zoom"] = round(zoom, 2)
    pal = thumb_palette(plan)
    band = choose_text_band(base, hint, pbox)
    plan["_used_text_position"] = band

    layer, label_box, (tl, tr), content_bottom, mood = _text_block(plan, s, W, pal)
    d = ImageDraw.Draw(layer)
    rnd = random.Random(abs(hash(plan.get("cover_big", ""))) & 0xffff)
    doodles = [k for k in (plan.get("doodles") or []) if k in DOODLE_KINDS]
    for k in MOODS[mood]:
        if len(doodles) >= 6: break
        if k not in doodles: doodles.append(k)
    colors = [pal["acc"], pal["sub"], (255, 255, 255), pal["yellow"]]
    clamp = lambda v: min(W - 55, max(55, v))
    spots = []
    if label_box:
        spots += [(clamp(label_box[0] - 60), label_box[1] + 45), (clamp(label_box[2] + 60), label_box[1] + 30)]
    spots += [(clamp(tl - 45), content_bottom - 130), (clamp(tr + 40), content_bottom - 160),
              (clamp(tr - 30), content_bottom + 10), (clamp(tl + 50), content_bottom + 15)]
    for i, (kind, (sx, sy)) in enumerate(zip(doodles, spots)):
        col = {"heart": (255, 110, 150)}.get(kind, colors[i % len(colors)])
        draw_doodle(d, kind, sx, sy, 1.15 + rnd.random() * 0.25, col, outline=pal["deep"])
    emos = [e for e in (plan.get("cover_emojis") or []) if e][:2]
    if emos:
        st = emoji_sticker(emos[0], 120)
        if st:
            layer.alpha_composite(st, (int(min(W - st.width - 10, tr - st.width * 0.3)), int(max(0, content_bottom - st.height - 150))))
    bbox = layer.getbbox() or (0, 0, W, 600)
    layer = layer.crop((0, max(0, bbox[1] - 10), W, min(layer.height, bbox[3] + 10)))
    layer = layer.rotate(3, resample=Image.BICUBIC, center=(W / 2, layer.height / 2))
    ty = {"top": int(H * SAFE_TOP) + 40, "middle": int(H * 0.50 - layer.height / 2)}.get(band, int(H * SAFE_BOTTOM - layer.height))
    base.alpha_composite(layer, (0, ty))
    text_area = (ty, ty + layer.height)

    # 제품 주변 꾸미기: 제품 위치를 알면 제품 옆에 반짝이·동작선, 모르면 글자 없는 쪽에
    dd = ImageDraw.Draw(base)
    if pbox:
        px0, py0, px1, py1 = [v * W if i % 2 == 0 else v * H for i, v in enumerate(pbox)]
        pts = [(px0 - 40, py0 + 30), (px1 + 40, py0 + 60), (px1 + 30, py1 - 80)]
    else:
        fy = (int(H * 0.55), int(H * 0.72)) if band != "bottom" else (int(H * 0.22), int(H * 0.40))
        pts = [(rnd.choice([rnd.randint(70, 260), rnd.randint(W - 260, W - 70)]), rnd.randint(*fy)) for _ in range(3)]
    for i, (sx, sy) in enumerate(pts):
        if text_area[0] - 30 < sy < text_area[1] + 30: continue
        kind = "motion" if (i == 1 and mood in ("funny", "surprise", "cool")) else "sparkle"
        draw_doodle(dd, kind, min(W - 50, max(50, sx)), sy, 0.75 + rnd.random() * 0.45, [pal["yellow"], (255, 255, 255), pal["sub"]][i % 3], outline=pal["deep"])
    bub = (plan.get("cover_bubble") or "").strip()
    if bub:
        bi = speech_bubble(bub[:10], s, pal)
        bx = 50 if (not pbox or (pbox[0] + pbox[2]) / 2 > 0.5) else W - bi.width - 50
        by_ = text_area[1] + 40 if band != "bottom" else text_area[0] - bi.height - 30
        by_ = max(int(H * SAFE_TOP), min(int(H * SAFE_BOTTOM) - bi.height, by_))
        base.alpha_composite(bi, (bx, by_))
    if len(emos) > 1:
        st2 = emoji_sticker(emos[1], 100)
        if st2:
            base.alpha_composite(st2, (W - st2.width - 60, int(H * 0.62)))
    cname = plan.get("_character", s.get("thumb_character", ""))
    cpath = char_path(cname) if cname else None
    if allow_sticker and plan.get("thumbnail_style") == "sticker" and cpath:
        st = make_sticker(cpath, 270)
        cx = int(min(W - st.width - 20, tr - st.width * 0.25))
        cy = text_area[1] - 40 if band != "bottom" else text_area[0] - st.height + 40
        cy = max(int(H * SAFE_TOP), min(int(H * SAFE_BOTTOM) - st.height, cy))
        base.alpha_composite(st, (cx, cy))
    if s.get("ad_label", True):
        f = font("Jua-Regular.ttf", 40)
        ImageDraw.Draw(base).text((W - 50, int(H * SAFE_TOP) + 8), "[광고]", font=f, anchor="rt",
                                  fill=(240, 240, 240, 220), stroke_width=2, stroke_fill=(90, 90, 90, 170))
    base.convert("RGB").save(out_path, quality=95)

# ---------------------------------------------------------------- 내 캐릭터 사진 등록
CHAR_DIR = os.path.join(HERE, "내캐릭터")

def _char_db():
    p = os.path.join(CHAR_DIR, "characters.json")
    if os.path.exists(p):
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    return {}

def _save_char_db(db):
    os.makedirs(CHAR_DIR, exist_ok=True)
    with open(os.path.join(CHAR_DIR, "characters.json"), "w", encoding="utf-8") as f:
        json.dump(db, f, ensure_ascii=False, indent=2)

def list_characters():
    return list(_char_db().keys())

def char_path(name):
    fn = _char_db().get(name)
    p = os.path.join(CHAR_DIR, fn) if fn else None
    return p if p and os.path.exists(p) else None

def register_character(src_path, name):
    name = name.strip()
    if not name:
        raise ValueError("캐릭터 이름을 넣어주세요.")
    os.makedirs(CHAR_DIR, exist_ok=True)
    im = Image.open(src_path)
    im = im.convert("RGBA")
    im.thumbnail((1200, 1200))
    safe = re.sub(r'[\\/:*?"<>|]', "_", name)
    fn = f"{safe}.png"
    im.save(os.path.join(CHAR_DIR, fn))
    db = _char_db(); db[name] = fn; _save_char_db(db)
    return os.path.join(CHAR_DIR, fn)

def delete_character(name):
    db = _char_db(); fn = db.pop(name, None); _save_char_db(db)
    if fn and os.path.exists(os.path.join(CHAR_DIR, fn)):
        os.remove(os.path.join(CHAR_DIR, fn))

def make_sticker(path, size=280, border=12):
    """배경이 투명한 PNG면 외곽 흰 테두리 스티커, 아니면 동그란 배지 스티커"""
    im = Image.open(path).convert("RGBA")
    a = im.getchannel("A")
    transparent_ratio = sum(1 for v in a.resize((64, 64)).getdata() if v < 30) / 4096
    if transparent_ratio > 0.05:
        im = im.crop(a.getbbox() or (0, 0, im.width, im.height))
        im.thumbnail((size, size), Image.LANCZOS)
        pad = border + 10
        canvas = Image.new("RGBA", (im.width + pad * 2, im.height + pad * 2), (0, 0, 0, 0))
        canvas.paste(im, (pad, pad), im)
        alpha = canvas.getchannel("A").point(lambda v: 255 if v > 40 else 0)
        k = border * 2 + 1
        grown = alpha.filter(ImageFilter.MaxFilter(k if k % 2 else k + 1))
        white = Image.new("RGBA", canvas.size, (255, 255, 255, 255)); white.putalpha(grown)
        shadow = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
        sh = Image.new("RGBA", canvas.size, (0, 0, 0, 90)); sh.putalpha(grown.point(lambda v: v * 90 // 255))
        shadow.alpha_composite(sh, (4, 6)); shadow = shadow.filter(ImageFilter.GaussianBlur(5))
        out = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
        out.alpha_composite(shadow); out.alpha_composite(white); out.alpha_composite(canvas)
        return out
    # 투명 배경이 아니면: 얼굴 쪽(위쪽 가운데)을 동그렇게
    w, h = im.size; side = min(w, h)
    top = int((h - side) * 0.12) if h > w else 0
    left = (w - side) // 2
    im = im.crop((left, top, left + side, top + side)).resize((size, size), Image.LANCZOS)
    full = size + border * 2
    out = Image.new("RGBA", (full + 12, full + 12), (0, 0, 0, 0))
    d = ImageDraw.Draw(out)
    sh = Image.new("RGBA", out.size, (0, 0, 0, 0)); ImageDraw.Draw(sh).ellipse((6, 9, full + 6, full + 9), fill=(0, 0, 0, 90))
    out.alpha_composite(sh.filter(ImageFilter.GaussianBlur(5)))
    d.ellipse((0, 0, full, full), fill=(255, 255, 255, 255))
    mask = Image.new("L", (size, size), 0); ImageDraw.Draw(mask).ellipse((0, 0, size, size), fill=255)
    out.paste(im, (border, border), mask)
    return out

# ---------------------------------------------------------------- AI 연출 썸네일 (GPT/Gemini 웹에서 이미지 받기)
def _persona_scene():
    p = os.path.join(HERE, "persona.json")
    if os.path.exists(p):
        try:
            with open(p, encoding="utf-8") as f:
                places = json.load(f).get("places") or []
            if places:
                return places[0]
        except Exception:
            pass
    return "햇살 드는 아늑한 방"

def my_character(s, plan=None):
    """썸네일에 쓸 내 캐릭터 이름 (결과별 지정 > 설정 > 등록된 첫 캐릭터)"""
    if plan and plan.get("_character") is not None:
        return plan["_character"] or ""
    name = s.get("thumb_character", "")
    if name and char_path(name):
        return name
    names = list_characters()
    return names[0] if names else ""

def ai_scene_prompt(plan, with_char):
    prod = plan.get("product") or "제품"
    band = plan.get("_used_text_position") or plan.get("thumbnail_text_position", "top")
    space = {"top": "화면 위쪽 1/3", "middle": "화면 가운데 가로 띠", "bottom": "화면 아래쪽 1/3(맨 아래 15%는 제외)"}.get(band, "화면 위쪽 1/3")
    act = (plan.get("character_action") or "").strip()
    place = (plan.get("scene_place") or "").strip() or _persona_scene()
    L = ["레퍼런스 1 = 실제 제품 사진." + (" 레퍼런스 2 = 내 캐릭터." if with_char else ""),
         "인스타 릴스 커버용 세로 9:16 사진을 만들어줘."]
    if with_char:
        L.append("[캐릭터] 레퍼런스 2와 완전히 같은 사람. 얼굴, 머리, 시그니처 아이템, 옷, 반실사 스타일을 그대로 유지.")
        L.append(f"[연출] {act or '캐릭터가 제품을 직접 쓰거나 착용한 모습, 표정이 살아 있게'}.")
    else:
        L.append(f"[연출] 제품이 주인공인 연출컷. {act or '제품이 가장 예쁘고 신기해 보이는 순간'}. 손이 나와도 되지만 얼굴은 나오지 않게(누드톤 광택 네일).")
    L.append(f"[제품] 레퍼런스 1의 {prod}을(를) 모양·색·로고·크기 비율 그대로. 다른 물건으로 바꾸거나 디자인을 바꾸지 마.")
    face = {"top": "얼굴과 제품은 세로 45~85% 지점(화면 아래쪽)에 두고", "bottom": "얼굴과 제품은 세로 15~50% 지점(화면 위쪽)에 두고",
            "middle": "얼굴은 위쪽, 제품은 아래쪽에 두고"}.get(band, "")
    L.append(f"[구도] 제품이 화면에서 가장 크고 눈에 띄게. {face if with_char else ''} {space}은 벽·하늘 같은 단순한 배경만 보이게 비워둬(글자 넣을 자리). 이 빈 자리에 얼굴·손·제품이 걸치면 안 돼.")
    L.append(f"[배경] {place}, 밝고 따뜻한 파스텔 생활 공간, 자연광, 폰으로 찍은 듯한 실제 사진 느낌, 색감 선명하게.")
    L.append("[금지] 글자, 숫자, 로고 추가, 워터마크, 테두리 없음.")
    return "\n".join(L)

def prepare_ai_thumb(outdir, s):
    """AI 연출용 참고 이미지(제품 장면, 캐릭터)와 프롬프트를 '썸네일_AI연출' 폴더에 준비"""
    plan = load_result(outdir); src = plan.get("_source")
    if not src or not os.path.exists(src):
        raise RuntimeError("원본 영상을 찾을 수 없어요. 썸네일을 한 번 다시 만들어 원본을 연결해 주세요.")
    d = os.path.join(outdir, "썸네일_AI연출"); os.makedirs(d, exist_ok=True)
    for f in os.listdir(d):
        if f.startswith("참고"):
            os.remove(os.path.join(d, f))
    extract_frame(src, float(plan.get("thumbnail_time", 1.0)), os.path.join(d, "참고1_제품.jpg"), probe(src)["duration"])
    with_char = plan.get("thumbnail_style") == "character_scene"
    cname = my_character(s, plan) if with_char else ""
    if with_char and cname:
        Image.open(char_path(cname)).convert("RGB").save(os.path.join(d, "참고2_캐릭터.jpg"), quality=95)
    prompt = ai_scene_prompt(plan, with_char and bool(cname))
    with open(os.path.join(d, "프롬프트.txt"), "w", encoding="utf-8") as f:
        f.write(prompt)
    return d, prompt

def thumbnail_from_image(outdir, s, img_path):
    """GPT/Gemini가 만든 사진 위에 글자·낙서·말풍선·[광고]를 얹어 썸네일.jpg로 저장 (영상 장면 버전은 따로 보관)"""
    plan = dict(load_result(outdir))
    cur = os.path.join(outdir, "썸네일.jpg"); keep = os.path.join(outdir, "썸네일_영상장면.jpg")
    if os.path.exists(cur) and not os.path.exists(keep):
        shutil.copy(cur, keep)
    render_thumbnail(img_path, plan, s, cur, allow_sticker=False, use_box=False)
    log(f"  AI 연출 썸네일 완료: {cur}")
    return cur

# ---------------------------------------------------------------- 다시 만들기
def load_result(outdir):
    with open(os.path.join(outdir, "편집계획.json"), encoding="utf-8") as f:
        return json.load(f)

def save_result_plan(outdir, plan):
    with open(os.path.join(outdir, "편집계획.json"), "w", encoding="utf-8") as f:
        json.dump(plan, f, ensure_ascii=False, indent=2)

def rerender_video(outdir, s, src=None):
    plan = load_result(outdir); src = src or plan.get("_source")
    if not src or not os.path.exists(src):
        raise RuntimeError("원본 영상을 찾을 수 없어요. 원본 영상을 다시 골라주세요.")
    plan = sanitize_plan(plan, probe(src)["duration"], s); plan["_source"] = src
    save_result_plan(outdir, plan)
    work = os.path.join(outdir, "_작업"); os.makedirs(work, exist_ok=True)
    log("  - 영상 다시 만드는 중...")
    total, _ = render_video(src, plan, s, os.path.join(outdir, "완성영상.mp4"), work)
    write_texts(plan, s, outdir)
    log(f"  영상 완료 ({total:.1f}초): {outdir}")

def rerender_thumbnail(outdir, s, src=None):
    plan = load_result(outdir); src = src or plan.get("_source")
    if not src or not os.path.exists(src):
        raise RuntimeError("원본 영상을 찾을 수 없어요. 원본 영상을 다시 골라주세요.")
    dur = probe(src)["duration"]
    plan = sanitize_plan(plan, dur, s); plan["_source"] = src
    save_result_plan(outdir, plan)
    work = os.path.join(outdir, "_작업"); os.makedirs(work, exist_ok=True)
    log("  - 썸네일 다시 만드는 중...")
    make_thumbnail(src, plan, s, outdir, dur)

def make_thumbnail(src, plan, s, outdir, dur):
    """영상 장면 썸네일을 만들고, AI 연출 방식이면 GPT/Gemini용 참고 이미지·프롬프트도 준비"""
    work = os.path.join(outdir, "_작업"); os.makedirs(work, exist_ok=True)
    fr = os.path.join(work, "frame.jpg")
    extract_frame(src, plan["thumbnail_time"], fr, dur)
    out = os.path.join(outdir, "썸네일.jpg")
    render_thumbnail(fr, plan, s, out)
    save_result_plan(outdir, plan)
    st = plan.get("thumbnail_style", "product")
    log(f"  썸네일 완료 ({THUMB_STYLES.get(st, st)}, 글자 {({'top': '위', 'middle': '가운데', 'bottom': '아래'}).get(plan.get('_used_text_position'), '')}): {out}")
    if st in AI_STYLES:
        d, _ = prepare_ai_thumb(outdir, s)
        what = plan.get("character_action") or ("캐릭터 등장" if st == "character_scene" else "제품 연출컷")
        log(f"  ★ 이 영상은 AI 연출 썸네일이 더 어울려요: {what}")
        log("    '결과 다듬기'에서 [AI 이미지 받기] → [받은 이미지 넣기]. (지금은 영상 장면 썸네일이 들어 있어요)")
    return out

# ---------------------------------------------------------------- 렌더
def render_video(src, plan, s, out_path, work):
    W, H = 1080, 1920
    info = probe(src)
    segs = plan["segments"]
    total = sum(x["end"] - x["start"] for x in segs)
    subs = plan["subtitles"]
    # 자막 타이밍: 글자 수 비례(최소 1.2초)
    lens = [max(6, len(t)) for t in subs]
    times = []; acc = 0.0
    for L in lens:
        dt = total * L / sum(lens); times.append((acc, acc + dt)); acc += dt
    inputs = ["-i", src]
    overlays = []
    for i, t in enumerate(subs):
        p = os.path.join(work, f"sub_{i}.png")
        render_subtitle(t, s).save(p)
        inputs += ["-i", p]; overlays.append(i + 1)
    ad_idx = None
    if s.get("ad_label", True):
        p = os.path.join(work, "ad.png"); render_ad_label(W, H).save(p)
        inputs += ["-i", p]; ad_idx = len(overlays) + 1
    fc = []
    vlabels = []
    for i, sg in enumerate(segs):
        fc.append(f"[0:v]trim=start={sg['start']}:end={sg['end']},setpts=PTS-STARTPTS,"
                  f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},setsar=1,fps=30[v{i}]")
        vlabels.append(f"[v{i}]")
    keep_audio = s.get("keep_audio") and info["has_audio"]
    if keep_audio:
        for i, sg in enumerate(segs):
            fc.append(f"[0:a]atrim=start={sg['start']}:end={sg['end']},asetpts=PTS-STARTPTS[a{i}]")
        fc.append("".join(f"[v{i}][a{i}]" for i in range(len(segs))) + f"concat=n={len(segs)}:v=1:a=1[vc][ac]")
    else:
        fc.append("".join(vlabels) + f"concat=n={len(segs)}:v=1:a=0[vc]")
    cur = "vc"
    sub_y = int(H * 0.30) - 110
    for k, (idx, (a, b)) in enumerate(zip(overlays, times)):
        nxt = f"o{k}"
        fc.append(f"[{cur}][{idx}:v]overlay=0:{sub_y}:enable='between(t,{a:.2f},{b:.2f})'[{nxt}]")
        cur = nxt
    if ad_idx:
        fc.append(f"[{cur}][{ad_idx}:v]overlay=0:0[vad]"); cur = "vad"
    args = inputs + ["-filter_complex", ";".join(fc), "-map", f"[{cur}]"]
    if keep_audio:
        args += ["-map", "[ac]", "-c:a", "aac", "-b:a", "160k"]
    else:
        args += ["-an"]
    args += ["-c:v", "libx264", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p", "-movflags", "+faststart", out_path]
    ff(args)
    return total, times

def _sharpness(path):
    from PIL import ImageStat
    im = Image.open(path).convert("L").resize((360, 640))
    return ImageStat.Stat(im.filter(ImageFilter.FIND_EDGES)).var[0]

def extract_frame(src, t, out, dur=None):
    """t 앞뒤 0.6초 안에서 가장 선명한 프레임을 고른다 (흔들림 방지)"""
    best, bestv = None, -1
    for k, dt in enumerate([-0.6, -0.4, -0.2, 0, 0.2, 0.4, 0.6]):
        tt = max(0.0, t + dt)
        if dur: tt = min(tt, max(0.0, dur - 0.1))
        p = out + f".c{k}.jpg"
        try:
            ff(["-ss", f"{tt:.2f}", "-i", src, "-frames:v", "1", "-q:v", "2", p])
            v = _sharpness(p)
        except Exception:
            continue
        if v > bestv: best, bestv = p, v
    if best:
        shutil.copy(best, out)
    else:
        ff(["-ss", f"{t:.2f}", "-i", src, "-frames:v", "1", "-q:v", "2", out])
    for k in range(7):
        try: os.remove(out + f".c{k}.jpg")
        except OSError: pass

def make_proxy(src, out):
    ff(["-i", src, "-vf", "scale=-2:854", "-r", "15", "-c:v", "libx264", "-preset", "veryfast", "-crf", "30", "-an", out])

def write_texts(plan, s, outdir):
    cap = plan["caption"].strip() + "\n\n" + s["cta"].strip() + "\n\n" + " ".join(plan.get("hashtags", []))
    if s.get("coupang_notice"):
        cap += "\n\n" + s["coupang_notice"]
    with open(os.path.join(outdir, "캡션.txt"), "w", encoding="utf-8") as f:
        f.write(cap + "\n")
    with open(os.path.join(outdir, "쿠팡검색어_제목.txt"), "w", encoding="utf-8") as f:
        f.write("제품: " + plan.get("product", "") + "\n")
        f.write("쿠팡 검색어: " + " / ".join(plan.get("coupang_keywords", [])) + "\n")
        f.write("쇼츠 제목: " + plan.get("title", "") + "\n")
        f.write("\n자막:\n" + "\n".join(plan["subtitles"]) + "\n")

# ---------------------------------------------------------------- 실행
def process(src, outroot, s, plan_override=None):
    name = os.path.splitext(os.path.basename(src))[0]
    outdir = os.path.join(outroot, name); os.makedirs(outdir, exist_ok=True)
    work = os.path.join(outdir, "_작업"); os.makedirs(work, exist_ok=True)
    info = probe(src)
    log(f"[{name}] 길이 {info['duration']:.1f}초")
    plan_path = os.path.join(outdir, "편집계획.json")
    if plan_override:
        plan = plan_override
    elif os.path.exists(plan_path) and s.get("reuse_plan"):
        with open(plan_path, encoding="utf-8") as f:
            plan = json.load(f)
        log("  - 기존 편집계획.json 사용 (Gemini 호출 안 함)")
    else:
        proxy = os.path.join(work, "proxy.mp4")
        make_proxy(src, proxy)
        plan = gemini_plan(s, proxy, info["duration"])
    plan = sanitize_plan(plan, info["duration"], s)
    plan["_source"] = os.path.abspath(src)
    with open(plan_path, "w", encoding="utf-8") as f:
        json.dump(plan, f, ensure_ascii=False, indent=2)
    log("  - 영상 편집 중...")
    total, _ = render_video(src, plan, s, os.path.join(outdir, "완성영상.mp4"), work)
    log("  - 썸네일 만드는 중...")
    make_thumbnail(src, plan, s, outdir, info["duration"])
    write_texts(plan, s, outdir)
    log(f"  완료: {outdir} ({total:.1f}초)")
    return outdir

def run_folder(folder, s, outroot=None):
    outroot = outroot or os.path.join(folder, "결과")
    os.makedirs(outroot, exist_ok=True)
    vids = [p for p in sorted(glob.glob(os.path.join(folder, "*"))) if p.lower().endswith(VIDEO_EXT)]
    if not vids:
        log("폴더에 영상이 없어요.")
    done = []
    for v in vids:
        try:
            done.append(process(v, outroot, s))
        except Exception as e:
            log(f"[실패] {os.path.basename(v)}: {e}")
    log(f"끝. {len(done)}/{len(vids)}개 완료 → {outroot}")
    return done

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="신박템 자동편집기")
    ap.add_argument("folder", help="원본 영상 폴더")
    ap.add_argument("--plan", help="Gemini 대신 쓸 편집계획 JSON (테스트·수정용)")
    ap.add_argument("--reuse", action="store_true", help="결과 폴더의 편집계획.json을 고친 뒤 다시 렌더")
    ap.add_argument("--out", help="결과 폴더")
    a = ap.parse_args()
    st = load_settings(); st["reuse_plan"] = a.reuse
    if a.plan:
        with open(a.plan, encoding="utf-8") as f:
            pl = json.load(f)
        vids = [a.folder] if os.path.isfile(a.folder) else [p for p in sorted(glob.glob(os.path.join(a.folder, "*"))) if p.lower().endswith(VIDEO_EXT)]
        outroot = a.out or os.path.join(os.path.dirname(vids[0]), "결과")
        for v in vids:
            process(v, outroot, st, plan_override=dict(pl))
    else:
        run_folder(a.folder, st, a.out)
