@echo off
cd /d %~dp0
where python >nul 2>nul
if errorlevel 1 (
  echo [!] Python is not installed. Install Python 3.10+ from https://www.python.org/downloads/ and check "Add python.exe to PATH".
  pause
  exit /b 1
)
python -m pip install --upgrade pip
python -m pip install pillow imageio-ffmpeg
echo.
echo Done. Now double-click run.bat
pause
