# -*- coding: utf-8 -*-
"""자동 업데이트: 배포 주소의 version.json을 보고 새 버전이면 zip을 받아 프로그램 파일만 교체한다.
설정·페르소나·내 캐릭터 사진·결과물·사용자가 넣은 폰트는 그대로 둔다."""
import os, sys, json, shutil, zipfile, tempfile, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
KEEP = {"settings.json", "persona.json", "update_config.json"}
KEEP_DIRS = {"내캐릭터", "결과"}

def local_version():
    try:
        return open(os.path.join(HERE, "version.txt"), encoding="utf-8").read().strip()
    except Exception:
        return "0.0.0"

def _vt(v):
    return tuple(int(x) for x in str(v).strip().split(".") if x.isdigit())

def update_url():
    p = os.path.join(HERE, "update_config.json")
    try:
        return json.load(open(p, encoding="utf-8")).get("url", "").strip()
    except Exception:
        return ""

def check(url=None, timeout=8):
    """새 버전 정보 dict 또는 None"""
    url = url or update_url()
    if not url:
        return None
    with urllib.request.urlopen(urllib.request.Request(url, headers={"Cache-Control": "no-cache"}), timeout=timeout) as r:
        info = json.loads(r.read().decode("utf-8"))
    if _vt(info.get("version", "0")) > _vt(local_version()):
        return info
    return None

def apply(info, log=print):
    zurl = info["zip_url"]
    tmp = os.path.join(HERE, "_update_tmp"); shutil.rmtree(tmp, ignore_errors=True); os.makedirs(tmp)
    zpath = os.path.join(tmp, "update.zip")
    log(f"[업데이트] {info.get('version')} 내려받는 중...")
    with urllib.request.urlopen(zurl, timeout=120) as r, open(zpath, "wb") as f:
        shutil.copyfileobj(r, f)
    with zipfile.ZipFile(zpath) as z:
        names = [n for n in z.namelist() if not n.endswith("/")]
        prefix = os.path.commonprefix(names)
        prefix = prefix[:prefix.rfind("/") + 1] if "/" in prefix else ""
        n = 0
        for name in names:
            rel = name[len(prefix):]
            if not rel:
                continue
            top = rel.split("/")[0]
            if rel in KEEP or top in KEEP_DIRS:
                continue
            dest = os.path.join(HERE, *rel.split("/"))
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            with z.open(name) as src, open(dest, "wb") as out:
                shutil.copyfileobj(src, out)
            n += 1
    with open(os.path.join(HERE, "version.txt"), "w", encoding="utf-8") as f:
        f.write(str(info.get("version")))
    shutil.rmtree(tmp, ignore_errors=True)
    log(f"[업데이트] 완료: 파일 {n}개 교체 → 버전 {info.get('version')}. 프로그램을 다시 켜주세요.")
    return n

if __name__ == "__main__":
    try:
        info = check()
    except Exception as e:
        print("업데이트 확인 실패:", e); input("Enter를 누르면 닫혀요"); sys.exit(1)
    if not update_url():
        print("업데이트 주소가 설정돼 있지 않아요 (update_config.json).")
    elif not info:
        print(f"이미 최신 버전이에요 ({local_version()}).")
    else:
        print(f"새 버전 {info.get('version')}: {info.get('notes', '')}")
        apply(info)
    input("Enter를 누르면 닫혀요")
