# -*- coding: utf-8 -*-
"""신박템 자동편집기 화면: ① 페르소나 만들기 / ② 영상 제작하기 / ③ 결과 다듬기"""
import os, sys, threading, webbrowser, json, re
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext, simpledialog
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import autoedit as ae
import persona as pg
import update as upd

VIDEO_TYPES = [("영상", "*.mp4 *.mov *.m4v *.webm *.mkv")]
IMAGE_TYPES = [("이미지", "*.png *.jpg *.jpeg *.webp")]
HINT = "#7A6455"
MOOD_LABELS = {"cute": "귀여움", "funny": "웃김", "surprise": "놀람·신기", "cozy": "포근·힐링", "cool": "멋·기시기", "sad": "애잔·현타"}
POS_LABELS = {"top": "위", "middle": "가운데", "bottom": "아래"}

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"신박템 자동편집기  v{upd.local_version()}")
        self.geometry("940x920")
        self.s = ae.load_settings()
        self.persona = None
        style = ttk.Style(self)
        style.configure("Top.TNotebook.Tab", padding=(22, 8), font=("맑은 고딕", 11, "bold"))

        bar = ttk.Frame(self); bar.pack(fill="x", padx=8, pady=(6, 0))
        ttk.Button(bar, text="업데이트 확인", command=lambda: self.check_update(silent=False)).pack(side="right")
        self.top = ttk.Notebook(self, style="Top.TNotebook"); self.top.pack(fill="both", expand=True, padx=8, pady=4)
        self.tab_persona = ttk.Frame(self.top); self.top.add(self.tab_persona, text="① 페르소나 만들기")
        self.tab_make = ttk.Frame(self.top); self.top.add(self.tab_make, text="② 영상 제작하기")
        self.tab_fix = ttk.Frame(self.top); self.top.add(self.tab_fix, text="③ 결과 다듬기")

        self.v_name = tk.StringVar(value=self.s.get("persona_name", ""))
        self.v_desc = tk.StringVar(value=self.s.get("persona_desc", ""))
        self.v_cta = tk.StringVar(value=self.s.get("cta", ""))
        self.v_ad = tk.BooleanVar(value=self.s.get("ad_label", True))
        self.v_audio = tk.BooleanVar(value=self.s.get("keep_audio", False))
        self.v_tchar = tk.StringVar(value=self.s.get("thumb_character") or "없음")
        self.v_key = tk.StringVar(value=self.s.get("api_key", ""))
        self.v_folder = tk.StringVar(value=self.s.get("last_folder", ""))
        self.fonts = ae.list_fonts()
        cur = self.s.get("sub_font", "Jua-Regular.ttf")
        self.v_font = tk.StringVar(value=next((k for k, v in self.fonts.items() if v == cur), next(iter(self.fonts))))

        self.build_persona_tab(); self.build_make_tab(); self.build_fix_tab()
        lf = ttk.LabelFrame(self, text="진행 기록"); lf.pack(fill="both", padx=8, pady=(0, 8))
        self.logbox = scrolledtext.ScrolledText(lf, height=7); self.logbox.pack(fill="both", expand=True)
        ae.log = self.log
        self.refresh_chars(); self.preview_font()
        self.after(1500, lambda: self.check_update(silent=True))

    # ================================================================ 공통
    def log(self, msg):
        self.logbox.after(0, lambda: (self.logbox.insert("end", msg + "\n"), self.logbox.see("end")))

    def row(self, parent, label, var, r, show=None, width=74):
        ttk.Label(parent, text=label).grid(row=r, column=0, sticky="w", padx=6)
        e = ttk.Entry(parent, textvariable=var, width=width, show=show); e.grid(row=r, column=1, sticky="we", pady=3, padx=6)
        return e

    def collect(self):
        self.s.update({"api_key": self.v_key.get().strip(), "persona_name": self.v_name.get().strip(),
                       "persona_desc": self.v_desc.get().strip(), "cta": self.v_cta.get().strip(),
                       "ad_label": self.v_ad.get(), "keep_audio": self.v_audio.get(), "last_folder": self.v_folder.get(),
                       "thumb_character": "" if self.v_tchar.get() == "없음" else self.v_tchar.get(),
                       "sub_font": self.fonts.get(self.v_font.get(), "Jua-Regular.ttf")})
        for k in ("target_seconds", "thumb_char_pos"): self.s.pop(k, None)
        ae.save_settings({k: v for k, v in self.s.items() if k != "reuse_plan"})
        return dict(self.s)

    def check_update(self, silent=True):
        def job():
            try:
                info = upd.check()
            except Exception as e:
                if not silent: self.after(0, lambda: messagebox.showwarning("업데이트", f"확인 실패: {e}"))
                return
            if not info:
                if not silent:
                    msg = "업데이트 주소가 아직 설정되지 않았어요." if not upd.update_url() else f"이미 최신 버전이에요 (v{upd.local_version()})."
                    self.after(0, lambda: messagebox.showinfo("업데이트", msg))
                return
            def ask():
                if messagebox.askyesno("새 버전", f"새 버전 v{info.get('version')}이 있어요.\n\n{info.get('notes', '')}\n\n지금 업데이트할까요?"):
                    threading.Thread(target=lambda: self._do_update(info), daemon=True).start()
            self.after(0, ask)
        threading.Thread(target=job, daemon=True).start()

    def _do_update(self, info):
        try:
            upd.apply(info, log=self.log)
            self.after(0, lambda: (messagebox.showinfo("업데이트 완료", "업데이트가 끝났어요. 프로그램을 다시 켜주세요."), self.destroy()))
        except Exception as e:
            self.log(f"[업데이트 실패] {e}")

    # ================================================================ ① 페르소나 만들기
    def build_persona_tab(self):
        t = self.tab_persona
        g = ttk.LabelFrame(t, text="나이·성별만 넣으면 캐릭터가 만들어져요"); g.pack(fill="x", padx=8, pady=6)
        top = ttk.Frame(g); top.pack(fill="x", padx=6, pady=6)
        self.v_age = tk.StringVar(value="26"); self.v_gender = tk.StringVar(value="여"); self.v_vibe = tk.StringVar(value="랜덤")
        ttk.Label(top, text="나이").pack(side="left")
        ttk.Entry(top, textvariable=self.v_age, width=5).pack(side="left", padx=(4, 14))
        ttk.Label(top, text="성별").pack(side="left")
        ttk.Radiobutton(top, text="여", value="여", variable=self.v_gender).pack(side="left")
        ttk.Radiobutton(top, text="남", value="남", variable=self.v_gender).pack(side="left", padx=(0, 14))
        ttk.Label(top, text="분위기").pack(side="left")
        ttk.Combobox(top, textvariable=self.v_vibe, values=["랜덤"] + pg.VIBES, width=8, state="readonly").pack(side="left", padx=(4, 14))
        ttk.Button(top, text="🎲 페르소나 뽑기", command=self.make_persona).pack(side="left")
        self.ptext = scrolledtext.ScrolledText(g, height=10); self.ptext.pack(fill="x", padx=6)
        pb = ttk.Frame(g); pb.pack(fill="x", padx=6, pady=6)
        ttk.Button(pb, text="마음에 들어요 → 이 말투로 적용", command=self.apply_persona).pack(side="left")
        ttk.Button(pb, text="GPT 이미지 프롬프트 (기준 이미지 · 프사)", command=self.show_prompts).pack(side="left", padx=6)
        ttk.Label(g, text="마음에 안 들면 다시 뽑기. 글을 직접 고쳐도 돼요.", foreground=HINT).pack(anchor="w", padx=6, pady=(0, 6))

        c = ttk.LabelFrame(t, text="내 캐릭터 사진 (썸네일에 쓸 사진 등록)"); c.pack(fill="x", padx=8, pady=6)
        self.lb_chars = tk.Listbox(c, height=8, width=22); self.lb_chars.grid(row=0, column=0, rowspan=4, sticky="ns", padx=6, pady=6)
        self.lb_chars.bind("<<ListboxSelect>>", lambda e: self.preview_char())
        cbx = ttk.Frame(c); cbx.grid(row=0, column=1, sticky="nw", pady=6)
        ttk.Button(cbx, text="사진 올려서 등록", command=self.add_char).pack(fill="x", pady=2)
        ttk.Button(cbx, text="내 캐릭터로 지정", command=self.set_default_char).pack(fill="x", pady=2)
        ttk.Button(cbx, text="선택 삭제", command=self.del_char).pack(fill="x", pady=2)
        self.char_preview = ttk.Label(c, text="(미리보기)"); self.char_preview.grid(row=0, column=2, rowspan=4, padx=10, pady=6)
        ttk.Label(c, text="PNG 배경이 투명하면 외곽선 스티커, 아니면 동그란 배지로 붙어요.", foreground=HINT).grid(row=4, column=0, columnspan=3, sticky="w", padx=6, pady=(0, 6))

    def make_persona(self):
        try:
            age = int(self.v_age.get())
        except ValueError:
            messagebox.showwarning("나이", "나이를 숫자로 넣어주세요."); return
        vibe = self.v_vibe.get(); vibe = None if vibe == "랜덤" else vibe
        self.persona = pg.generate(age, self.v_gender.get(), vibe)
        self.ptext.delete("1.0", "end"); self.ptext.insert("1.0", pg.to_text(self.persona))

    def apply_persona(self):
        if not self.persona:
            messagebox.showinfo("페르소나", "먼저 페르소나를 뽑아주세요."); return
        m = re.search(r"이름:\s*(\S+)", self.ptext.get("1.0", "end"))
        if m: self.persona["name"] = m.group(1)
        self.v_name.set(self.persona["name"]); self.v_desc.set(self.persona["desc"])
        self.collect()
        with open(os.path.join(ae.HERE, "persona.json"), "w", encoding="utf-8") as f:
            json.dump(self.persona, f, ensure_ascii=False, indent=2)
        self.log(f"[페르소나] '{self.persona['name']}' 적용 완료. 이제 자막·캡션이 이 말투로 나와요.")

    def show_prompts(self):
        if not self.persona:
            messagebox.showinfo("페르소나", "먼저 페르소나를 뽑아주세요."); return
        prompts = pg.image_prompts(self.persona)
        path = os.path.join(ae.HERE, f"캐릭터프롬프트_{self.persona['name']}.txt")
        with open(path, "w", encoding="utf-8") as f:
            f.write(pg.prompts_text(self.persona))
        win = tk.Toplevel(self); win.title(f"{self.persona['name']} - GPT 이미지 프롬프트"); win.geometry("820x520")
        ttk.Label(win, text="① 기준 이미지 → 마음에 들면 저장해서 [등록] → ②에 그 이미지를 첨부해서 프사 만들기").pack(anchor="w", padx=10, pady=6)
        ttk.Button(win, text="ChatGPT 열기", command=lambda: webbrowser.open("https://chatgpt.com/")).pack(anchor="w", padx=10)
        for i, (k, v) in enumerate(prompts.items()):
            fr = ttk.LabelFrame(win, text=k); fr.pack(fill="x", padx=10, pady=6)
            tx = tk.Text(fr, height=7, wrap="word"); tx.insert("1.0", v); tx.pack(side="left", fill="x", expand=True, padx=4, pady=4)
            bf = ttk.Frame(fr); bf.pack(side="left", padx=4)
            ttk.Button(bf, text="복사", command=lambda v=v: (self.clipboard_clear(), self.clipboard_append(v), self.log("[프롬프트] 복사했어요. ChatGPT에 Ctrl+V"))).pack(fill="x", pady=2)
            if i == 0:
                ttk.Button(bf, text="결과 이미지\n내 캐릭터로 등록", command=lambda: self.add_char(default_name=self.persona["name"])).pack(fill="x", pady=2)
        self.log(f"[프롬프트] 파일로도 저장: {path}")

    def refresh_chars(self):
        names = ae.list_characters()
        self.lb_chars.delete(0, "end")
        for n in names: self.lb_chars.insert("end", n)
        self.cb_tchar["values"] = ["없음"] + names
        if self.v_tchar.get() not in ["없음"] + names: self.v_tchar.set(names[0] if names else "없음")

    def add_char(self, default_name=None):
        p = filedialog.askopenfilename(title="캐릭터 사진", filetypes=IMAGE_TYPES)
        if not p: return
        name = simpledialog.askstring("캐릭터 이름", "이 사진을 어떤 이름으로 등록할까요?", initialvalue=default_name or self.v_name.get(), parent=self)
        if not name: return
        try:
            ae.register_character(p, name)
        except Exception as e:
            messagebox.showerror("등록 실패", str(e)); return
        self.refresh_chars(); self.log(f"[캐릭터] '{name}' 등록 완료")
        names = ae.list_characters()
        if name in names:
            self.lb_chars.selection_clear(0, "end"); self.lb_chars.selection_set(names.index(name)); self.preview_char()

    def selected_char(self):
        sel = self.lb_chars.curselection()
        return self.lb_chars.get(sel[0]) if sel else None

    def preview_char(self):
        n = self.selected_char()
        if not n: return
        try:
            from PIL import ImageTk
            st = ae.make_sticker(ae.char_path(n), 200)
            bg = ae.Image.new("RGBA", st.size, (210, 210, 210, 255)); bg.alpha_composite(st)
            self._char_img = ImageTk.PhotoImage(bg)
            self.char_preview.configure(image=self._char_img, text="")
        except Exception as e:
            self.char_preview.configure(text=f"미리보기 실패: {e}", image="")

    def set_default_char(self):
        n = self.selected_char()
        if not n: return
        self.v_tchar.set(n); self.collect(); self.log(f"[캐릭터] 내 캐릭터: {n}")

    def del_char(self):
        n = self.selected_char()
        if not n or not messagebox.askyesno("삭제", f"'{n}' 사진을 지울까요?"): return
        ae.delete_character(n); self.refresh_chars(); self.char_preview.configure(image="", text="(미리보기)")

    # ================================================================ ② 영상 제작하기
    def build_make_tab(self):
        t = self.tab_make
        f = ttk.LabelFrame(t, text="설정 (한 번 넣으면 저장돼요)"); f.pack(fill="x", padx=8, pady=6)
        self.row(f, "캐릭터 이름", self.v_name, 0)
        self.row(f, "캐릭터 말투", self.v_desc, 1)
        self.row(f, "캡션 댓글 유도", self.v_cta, 2)
        ttk.Label(f, text="자막 폰트").grid(row=3, column=0, sticky="nw", padx=6, pady=4)
        ff = ttk.Frame(f); ff.grid(row=3, column=1, sticky="w", padx=6, pady=4)
        cb = ttk.Combobox(ff, textvariable=self.v_font, values=list(self.fonts.keys()), width=26, state="readonly"); cb.pack(side="left", anchor="n")
        cb.bind("<<ComboboxSelected>>", lambda e: (self.preview_font(), self.collect()))
        self.font_prev = ttk.Label(ff); self.font_prev.pack(side="left", padx=10)
        ttk.Label(f, text="내 캐릭터").grid(row=4, column=0, sticky="w", padx=6)
        cf = ttk.Frame(f); cf.grid(row=4, column=1, sticky="w", padx=6, pady=3)
        self.cb_tchar = ttk.Combobox(cf, textvariable=self.v_tchar, width=14, state="readonly"); self.cb_tchar.pack(side="left")
        ttk.Label(cf, text="썸네일에 캐릭터를 넣을지·어떻게 넣을지는 영상마다 자동 판단 (없음 = 캐릭터 안 씀)", foreground=HINT).pack(side="left", padx=8)
        op = ttk.Frame(f); op.grid(row=5, column=1, sticky="w", padx=6, pady=2)
        ttk.Checkbutton(op, text="[광고] 표기", variable=self.v_ad).pack(side="left")
        ttk.Checkbutton(op, text="원본 소리 유지 (끄면 무음, 음악은 업로드할 때 앱에서)", variable=self.v_audio).pack(side="left", padx=12)
        ttk.Label(f, text="완성 길이는 5~10초 사이에서 영상에 맞게 자동", foreground=HINT).grid(row=6, column=1, sticky="w", padx=6, pady=(0, 4))
        f.columnconfigure(1, weight=1)

        sub = ttk.Notebook(t); sub.pack(fill="x", padx=8, pady=6)
        w = ttk.Frame(sub); sub.add(w, text="  API 없이 (Gemini 웹)  ")
        self.v_video = tk.StringVar(value="")
        ttk.Label(w, text="원본 영상 1개").grid(row=0, column=0, sticky="w", padx=6, pady=6)
        vf = ttk.Frame(w); vf.grid(row=0, column=1, sticky="we", padx=6)
        ttk.Entry(vf, textvariable=self.v_video, width=60).pack(side="left", fill="x", expand=True)
        ttk.Button(vf, text="영상 고르기", command=self.pick_video).pack(side="left", padx=4)
        ttk.Button(w, text="① 프롬프트 복사 + Gemini 열기", command=self.step1).grid(row=1, column=1, sticky="w", padx=6, pady=4)
        ttk.Label(w, text="   → Gemini 입력창에 'Gemini에_올릴_영상.mp4'를 끌어놓고 Ctrl+V → 보내기", foreground=HINT).grid(row=2, column=1, sticky="w", padx=6)
        ttk.Label(w, text="② Gemini 답변\n    전체 붙여넣기").grid(row=3, column=0, sticky="nw", padx=6, pady=4)
        self.answer = scrolledtext.ScrolledText(w, height=7); self.answer.grid(row=3, column=1, sticky="we", padx=6, pady=4)
        ttk.Button(w, text="③ 이 답으로 만들기", command=self.step3).grid(row=4, column=1, sticky="w", padx=6, pady=6)
        w.columnconfigure(1, weight=1)
        a = ttk.Frame(sub); sub.add(a, text="  자동 (Gemini API 키)  ")
        self.row(a, "Gemini API 키", self.v_key, 0, show="*")
        ttk.Label(a, text="원본 영상 폴더").grid(row=1, column=0, sticky="w", padx=6)
        fo = ttk.Frame(a); fo.grid(row=1, column=1, sticky="we", padx=6)
        ttk.Entry(fo, textvariable=self.v_folder, width=58).pack(side="left", fill="x", expand=True)
        ttk.Button(fo, text="찾기", command=self.pick_folder).pack(side="left", padx=4)
        ttk.Button(a, text="▶ 폴더 전체 자동 편집", command=self.start).grid(row=2, column=1, sticky="w", padx=6, pady=6)
        ttk.Label(a, text="API 키는 aistudio.google.com 에서 무료 발급. 폴더 안 영상을 전부 처리해요.", foreground=HINT).grid(row=3, column=1, sticky="w", padx=6, pady=(0, 6))
        a.columnconfigure(1, weight=1)

    def preview_font(self):
        try:
            from PIL import ImageTk
            s = {"sub_font": self.fonts.get(self.v_font.get(), "Jua-Regular.ttf")}
            sub = ae.render_subtitle("버리긴 아까워서 케이스에 꽂아둠 💛", s)
            bg = ae.Image.new("RGBA", sub.size, (120, 130, 140, 255)); bg.alpha_composite(sub)
            bg = bg.crop((60, 40, sub.width - 60, sub.height - 40)).resize((480, 64))
            self._font_img = ImageTk.PhotoImage(bg)
            self.font_prev.configure(image=self._font_img)
        except Exception as e:
            self.font_prev.configure(text=f"미리보기 실패: {e}")

    def outroot_for(self, video):
        return os.path.join(os.path.dirname(video), "결과")

    def pick_video(self):
        p = filedialog.askopenfilename(filetypes=VIDEO_TYPES)
        if p: self.v_video.set(p)

    def pick_folder(self):
        d = filedialog.askdirectory()
        if d: self.v_folder.set(d)

    def step1(self):
        src = self.v_video.get()
        if not os.path.isfile(src):
            messagebox.showwarning("영상", "원본 영상 1개를 골라주세요."); return
        s = self.collect()
        def job():
            try:
                self.log("[①] Gemini에 올릴 가벼운 영상 만드는 중...")
                proxy, dur = ae.prepare_web(src, self.outroot_for(src))
                prompt = ae.web_prompt(s, dur)
                self.after(0, lambda: (self.clipboard_clear(), self.clipboard_append(prompt)))
                self.log("[①] 프롬프트 복사 완료. Gemini에 영상 끌어놓기 → Ctrl+V → 보내기 → 답변 전체를 ②칸에 붙여넣고 ③")
                os.startfile(os.path.dirname(proxy)); webbrowser.open("https://gemini.google.com/app")
            except Exception as e:
                self.log(f"[실패] {e}")
        threading.Thread(target=job, daemon=True).start()

    def step3(self):
        src = self.v_video.get()
        if not os.path.isfile(src):
            messagebox.showwarning("영상", "원본 영상 1개를 골라주세요."); return
        try:
            plan = ae.parse_plan_text(self.answer.get("1.0", "end"))
        except Exception as e:
            messagebox.showerror("답변 확인", str(e)); return
        s = self.collect()
        def job():
            try:
                out = ae.process(src, self.outroot_for(src), s, plan_override=plan)
                self.after(0, lambda: self.load_result(out))
            except Exception as e:
                self.log(f"[실패] {e}")
        threading.Thread(target=job, daemon=True).start()

    def start(self):
        s = self.collect(); s["reuse_plan"] = False
        folder = self.v_folder.get()
        if not os.path.isdir(folder):
            messagebox.showwarning("폴더", "원본 영상 폴더를 골라주세요."); return
        if not s.get("api_key"):
            messagebox.showwarning("API 키", "API 키가 없으면 'API 없이 (Gemini 웹)' 탭을 써주세요."); return
        def job():
            done = ae.run_folder(folder, s)
            if done: self.after(0, lambda: self.load_result(done[-1]))
        threading.Thread(target=job, daemon=True).start()

    # ================================================================ ③ 결과 다듬기
    def build_fix_tab(self):
        r = ttk.Frame(self.tab_fix); r.pack(fill="x", padx=8, pady=6)
        self.v_result = tk.StringVar(value="")
        ttk.Label(r, text="결과 폴더").grid(row=0, column=0, sticky="w", padx=6, pady=4)
        rf = ttk.Frame(r); rf.grid(row=0, column=1, sticky="we", padx=6)
        ttk.Entry(rf, textvariable=self.v_result, width=60).pack(side="left", fill="x", expand=True)
        ttk.Button(rf, text="고르기", command=self.pick_result).pack(side="left", padx=4)
        vb = ttk.Frame(r); vb.grid(row=1, column=1, sticky="w", padx=6, pady=(2, 8))
        ttk.Button(vb, text="썸네일 보기", command=lambda: self.open_file("썸네일.jpg")).pack(side="left")
        ttk.Button(vb, text="영상 보기", command=lambda: self.open_file("완성영상.mp4")).pack(side="left", padx=6)
        ttk.Button(vb, text="결과 폴더 열기", command=lambda: os.path.isdir(self.v_result.get()) and os.startfile(self.v_result.get())).pack(side="left")

        ttk.Label(r, text="자막 (한 줄에 하나)").grid(row=2, column=0, sticky="nw", padx=6)
        self.t_subs = tk.Text(r, height=4, width=70); self.t_subs.grid(row=2, column=1, sticky="we", padx=6, pady=2)
        self.v_cs, self.v_cb, self.v_cl, self.v_ca, self.v_bub, self.v_emo, self.v_tt = (tk.StringVar() for _ in range(7))
        self.row(r, "썸네일 작은 줄", self.v_cs, 3)
        self.row(r, "썸네일 큰 줄", self.v_cb, 4)
        self.row(r, "큰 줄 나누기 ( / )", self.v_cl, 5)
        g = ttk.Frame(r); g.grid(row=6, column=1, sticky="w", padx=6, pady=2)
        ttk.Label(g, text="강조 단어").pack(side="left"); ttk.Entry(g, textvariable=self.v_ca, width=12).pack(side="left", padx=(4, 12))
        ttk.Label(g, text="말풍선").pack(side="left"); ttk.Entry(g, textvariable=self.v_bub, width=12).pack(side="left", padx=(4, 12))
        ttk.Label(g, text="이모지").pack(side="left"); ttk.Entry(g, textvariable=self.v_emo, width=6).pack(side="left", padx=4)
        self.v_mood = tk.StringVar(value="귀여움"); self.v_style = tk.StringVar(value="영상 장면"); self.v_tp = tk.StringVar(value="자동")
        g2 = ttk.Frame(r); g2.grid(row=7, column=1, sticky="w", padx=6, pady=2)
        ttk.Label(g2, text="분위기").pack(side="left")
        ttk.Combobox(g2, textvariable=self.v_mood, values=list(MOOD_LABELS.values()), width=9, state="readonly").pack(side="left", padx=(4, 12))
        ttk.Label(g2, text="썸네일 방식").pack(side="left")
        ttk.Combobox(g2, textvariable=self.v_style, values=list(ae.THUMB_STYLES.values()), width=22, state="readonly").pack(side="left", padx=(4, 12))
        ttk.Label(g2, text="글자 위치").pack(side="left")
        ttk.Combobox(g2, textvariable=self.v_tp, values=["자동", "위", "가운데", "아래"], width=6, state="readonly").pack(side="left", padx=4)
        g3 = ttk.Frame(r); g3.grid(row=8, column=1, sticky="w", padx=6, pady=2)
        ttk.Label(g3, text="썸네일 장면(초, 원본 기준)").pack(side="left"); ttk.Entry(g3, textvariable=self.v_tt, width=6).pack(side="left", padx=4)
        rb = ttk.Frame(r); rb.grid(row=9, column=1, sticky="w", padx=6, pady=8)
        ttk.Button(rb, text="저장 + 영상만 다시 만들기", command=lambda: self.redo("video")).pack(side="left")
        ttk.Button(rb, text="저장 + 썸네일만 다시 만들기", command=lambda: self.redo("thumb")).pack(side="left", padx=6)
        r.columnconfigure(1, weight=1)

        ai = ttk.LabelFrame(self.tab_fix, text="AI 연출 썸네일 (영상 장면이 아쉬울 때 · GPT나 Gemini로 새 사진 받기)")
        ai.pack(fill="x", padx=8, pady=6)
        self.ai_hint = ttk.Label(ai, text="썸네일 방식이 'AI 연출'이면 여기서 사진을 받아 넣어요.", foreground=HINT, wraplength=820, justify="left")
        self.ai_hint.grid(row=0, column=0, columnspan=2, sticky="w", padx=6, pady=4)
        ttk.Button(ai, text="ⓐ AI 이미지 프롬프트 복사 + ChatGPT 열기", command=self.ai_step1).grid(row=1, column=0, sticky="w", padx=6, pady=3)
        ttk.Button(ai, text="ⓑ 받은 이미지로 썸네일 만들기", command=self.ai_step2).grid(row=1, column=1, sticky="w", padx=6, pady=3)
        ttk.Label(ai, text="ChatGPT 입력창에 '썸네일_AI연출' 폴더의 참고 사진들을 끌어놓고 Ctrl+V → 나온 이미지 저장 → ⓑ. 글자·스티커는 프로그램이 얹어요.",
                  foreground=HINT, wraplength=820).grid(row=2, column=0, columnspan=2, sticky="w", padx=6, pady=(0, 8))

    def pick_result(self):
        d = filedialog.askdirectory(title="완성영상·편집계획.json이 있는 결과 폴더")
        if d: self.load_result(d)

    def load_result(self, d):
        try:
            p = ae.load_result(d)
        except Exception:
            messagebox.showwarning("결과 폴더", "편집계획.json이 있는 결과 폴더를 골라주세요."); return
        self.v_result.set(d)
        self.t_subs.delete("1.0", "end"); self.t_subs.insert("1.0", "\n".join(p.get("subtitles", [])))
        self.v_cs.set(p.get("cover_small", "")); self.v_cb.set(p.get("cover_big", "")); self.v_ca.set(p.get("cover_accent", ""))
        self.v_cl.set(" / ".join(p.get("cover_big_lines") or []))
        self.v_bub.set(p.get("cover_bubble", "")); self.v_emo.set(" ".join(p.get("cover_emojis") or []))
        self.v_tt.set(str(p.get("thumbnail_time", 1.0)))
        self.v_mood.set(MOOD_LABELS.get(p.get("cover_mood"), "귀여움"))
        self.v_style.set(ae.THUMB_STYLES.get(p.get("thumbnail_style", "product"), "영상 장면"))
        self.v_tp.set("자동")
        st = p.get("thumbnail_style", "product")
        if st in ae.AI_STYLES:
            self.ai_hint.configure(text=f"★ 이 영상은 AI 연출 썸네일을 추천해요: {p.get('character_action') or ae.THUMB_STYLES[st]}  (지금은 영상 장면 썸네일이 들어 있어요)", foreground="#C2410C")
        else:
            self.ai_hint.configure(text="이 영상은 영상 장면으로 충분하다고 판단했어요. 그래도 AI 사진을 쓰고 싶으면 썸네일 방식을 바꾸고 ⓐ부터 하세요.", foreground=HINT)
        self.top.select(self.tab_fix)
        self.log(f"[다듬기] 불러옴: {d}")

    def _apply_fields(self, p):
        p["subtitles"] = [x.strip() for x in self.t_subs.get("1.0", "end").splitlines() if x.strip()]
        p["cover_small"], p["cover_big"], p["cover_accent"] = self.v_cs.get().strip(), self.v_cb.get().strip(), self.v_ca.get().strip()
        p["cover_big_lines"] = [x.strip() for x in self.v_cl.get().split("/") if x.strip()]
        p["cover_bubble"] = self.v_bub.get().strip()
        p["cover_emojis"] = [x for x in self.v_emo.get().split() if x][:2]
        try: p["thumbnail_time"] = float(self.v_tt.get())
        except ValueError: pass
        p["cover_mood"] = next((k for k, v in MOOD_LABELS.items() if v == self.v_mood.get()), "cute")
        p["thumbnail_style"] = next((k for k, v in ae.THUMB_STYLES.items() if v == self.v_style.get()), "product")
        tp = {"위": "top", "가운데": "middle", "아래": "bottom"}.get(self.v_tp.get())
        if tp: p["thumbnail_text_position"] = tp
        return p

    def _ensure_source(self, p):
        src = p.get("_source")
        if not src or not os.path.exists(src):
            src = filedialog.askopenfilename(title="원본 영상을 골라주세요", filetypes=VIDEO_TYPES)
            if not src: return False
            p["_source"] = src
        return True

    def redo(self, what):
        d = self.v_result.get()
        try:
            p = ae.load_result(d)
        except Exception:
            messagebox.showwarning("결과 폴더", "결과 폴더를 먼저 골라주세요."); return
        p = self._apply_fields(p)
        if not self._ensure_source(p): return
        ae.save_result_plan(d, p)
        s = self.collect()
        def job():
            try:
                (ae.rerender_video if what == "video" else ae.rerender_thumbnail)(d, s)
                if what == "thumb": self.after(0, lambda: (self.load_result(d), self.open_file("썸네일.jpg")))
            except Exception as e:
                self.log(f"[실패] {e}")
        threading.Thread(target=job, daemon=True).start()

    def open_file(self, name):
        p = os.path.join(self.v_result.get(), name)
        if os.path.exists(p): os.startfile(p)

    def ai_step1(self):
        d = self.v_result.get()
        try:
            p = ae.load_result(d)
        except Exception:
            messagebox.showwarning("결과 폴더", "결과 폴더를 먼저 골라주세요."); return
        p = self._apply_fields(p)
        if p["thumbnail_style"] not in ae.AI_STYLES:
            p["thumbnail_style"] = "character_scene" if ae.my_character(self.collect(), p) else "product_scene"
            self.v_style.set(ae.THUMB_STYLES[p["thumbnail_style"]])
        if not self._ensure_source(p): return
        ae.save_result_plan(d, p)
        try:
            folder, prompt = ae.prepare_ai_thumb(d, self.collect())
        except Exception as e:
            messagebox.showerror("준비 실패", str(e)); return
        self.clipboard_clear(); self.clipboard_append(prompt)
        self.log("[AI 연출] 프롬프트 복사 완료. ChatGPT에 참고 사진(참고1, 참고2 순서)을 끌어놓고 Ctrl+V → 나온 이미지 저장 → ⓑ")
        os.startfile(folder); webbrowser.open("https://chatgpt.com/")

    def ai_step2(self):
        d = self.v_result.get()
        if not d or not os.path.exists(os.path.join(d, "편집계획.json")):
            messagebox.showwarning("결과 폴더", "결과 폴더를 먼저 골라주세요."); return
        img = filedialog.askopenfilename(title="GPT/Gemini가 만든 이미지", filetypes=IMAGE_TYPES)
        if not img: return
        p = self._apply_fields(ae.load_result(d)); ae.save_result_plan(d, p)
        s = self.collect()
        def job():
            try:
                os.startfile(ae.thumbnail_from_image(d, s, img))
            except Exception as e:
                self.log(f"[실패] {e}")
        threading.Thread(target=job, daemon=True).start()

if __name__ == "__main__":
    App().mainloop()
